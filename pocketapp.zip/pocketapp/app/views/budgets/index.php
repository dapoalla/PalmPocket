<?php require __DIR__ . '/../layout/header.php'; ?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h3>Budgets</h3>
  <a href="index.php?route=budget_create" class="btn btn-primary">Add Budget</a>
</div>
<div class="card"><div class="card-body p-0">
  <div class="table-responsive">
    <table class="table table-striped mb-0">
      <thead><tr>
        <th>Category</th><th>Description</th><th>Period</th><th>Amount</th><th>Spent</th><th>Status</th><th></th>
      </tr></thead>
      <tbody>
      <?php foreach ($budgets as $b): $cls = 'bg-success'; if ($b['percent']>=70) $cls='bg-warning'; if ($b['percent']>=90) $cls='bg-danger'; ?>
        <tr>
          <td><?= e($b['category']) ?></td>
          <td><?= e($b['description']) ?></td>
          <td><?= e($b['start_date']) ?> → <?= e($b['end_date']) ?></td>
          <td>₦<?= number_format((float)$b['amount'], 2) ?></td>
          <td>₦<?= number_format((float)$b['spent'], 2) ?></td>
          <td style="width:260px">
            <div class="progress" role="progressbar" aria-valuenow="<?= (int)$b['percent'] ?>" aria-valuemin="0" aria-valuemax="100">
              <div class="progress-bar <?= $cls ?>" style="width: <?= (int)$b['percent'] ?>%"><?= (int)$b['percent'] ?>%</div>
            </div>
          </td>
          <td class="text-end">
            <a class="btn btn-sm btn-outline-secondary" href="index.php?route=budget_edit&id=<?= (int)$b['id'] ?>">Edit</a>
            <form method="post" action="index.php?route=budget_delete&id=<?= (int)$b['id'] ?>" class="d-inline" onsubmit="return confirm('Delete budget?');">
              <?= csrf_field() ?>
              <button class="btn btn-sm btn-outline-danger">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div></div>
<?php require __DIR__ . '/../layout/footer.php'; ?>
