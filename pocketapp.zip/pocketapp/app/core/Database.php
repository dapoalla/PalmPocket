<?php
namespace App\Core;

use PDO;

class Database {
    public PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }
}
