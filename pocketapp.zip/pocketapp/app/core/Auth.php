<?php
namespace App\Core;

use PDO;

class Auth {
    private PDO $db;

    public function __construct(PDO $pdo) { $this->db = $pdo; }

    public function check(): bool { return !empty($_SESSION['user_id']); }

    public function attempt(string $email, string $password): bool {
        $stmt = $this->db->prepare('SELECT id, email, password_hash, name FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user && password_verify($password, $user['password_hash'])) {
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['user_name'] = $user['name'];
            return true;
        }
        return false;
    }

    public function user(): ?array {
        if (!$this->check()) return null;
        return [
            'id' => (int)$_SESSION['user_id'],
            'name' => (string)($_SESSION['user_name'] ?? ''),
        ];
    }

    public function logout(): void { session_unset(); session_destroy(); }
}
