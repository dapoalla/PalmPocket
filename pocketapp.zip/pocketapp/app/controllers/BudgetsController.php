<?php
namespace App\Controllers;

use App\Core\Auth;
use PDO;

class BudgetsController {
    private PDO $db; private Auth $auth;
    public function __construct(PDO $pdo, Auth $auth){ $this->db=$pdo; $this->auth=$auth; }

    public function index(): void {
        $uid = $this->auth->user()['id'];
        $budgets = $this->mine('SELECT b.*, c.name AS category FROM budgets b INNER JOIN categories c ON c.id=b.category_id WHERE b.user_id=? ORDER BY b.start_date DESC, b.id DESC', [$uid]);
        // compute spent for each
        foreach ($budgets as &$b) {
            $spent = $this->scalar("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE user_id=? AND category_id=? AND date BETWEEN ? AND ?", [$uid, $b['category_id'], $b['start_date'], $b['end_date']]);
            $b['spent'] = (float)$spent;
            $b['percent'] = $b['amount'] > 0 ? min(100, round(($b['spent'] / $b['amount']) * 100)) : 0;
            // Notify if exceeded within its active period and for current date window
            $today = date('Y-m-d');
            if ($today >= $b['start_date'] && $today <= $b['end_date'] && $b['spent'] > $b['amount']) {
                $monthLabel = date('F Y', strtotime($b['start_date']));
                $msg = 'Budget exceeded: ' . ($b['category'] ?? ('Category #' . $b['category_id'])) . ' (' . $monthLabel . ')';
                // Avoid duplicate notifications with same message in the same period
                $exists = $this->scalar('SELECT COUNT(*) FROM notifications WHERE user_id=? AND message=?', [$uid, $msg]);
                if ((int)$exists === 0) {
                    $this->db->prepare('INSERT INTO notifications(user_id,message,level) VALUES (?,?,?)')->execute([$uid, $msg, 'warning']);
                }
            }
        }
        unset($b);
        require __DIR__ . '/../views/budgets/index.php';
    }

    public function create(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $category_id = (int)($_POST['category_id'] ?? 0);
            $description = trim($_POST['description'] ?? '');
            $amount = (float)($_POST['amount'] ?? 0);
            $start_date = $_POST['start_date'] ?? date('Y-m-01');
            $end_date = $_POST['end_date'] ?? date('Y-m-t');
            if ($category_id <= 0 || $amount <= 0 || $description==='') {
                $error = 'Invalid input';
            } else {
                $this->db->prepare('INSERT INTO budgets(user_id, category_id, description, amount, start_date, end_date) VALUES (?,?,?,?,?,?)')
                    ->execute([$uid, $category_id, $description, $amount, $start_date, $end_date]);
                redirect('budgets');
            }
        }
        $cats = $this->mine("SELECT id,name FROM categories WHERE user_id=? AND type='expense' ORDER BY name", [$uid]);
        require __DIR__ . '/../views/budgets/create.php';
    }

    public function edit(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $id = (int)($_GET['id'] ?? 0);
        $bud = $this->one('SELECT * FROM budgets WHERE id=? AND user_id=?', [$id, $uid]);
        if (!$bud) { http_response_code(404); exit('Not found'); }
        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $category_id = (int)$_POST['category_id'];
            $description = trim($_POST['description'] ?? '');
            $amount = (float)($_POST['amount'] ?? 0);
            $start_date = $_POST['start_date'] ?? date('Y-m-01');
            $end_date = $_POST['end_date'] ?? date('Y-m-t');
            if ($category_id <= 0 || $amount <= 0 || $description==='') {
                $error = 'Invalid input';
            } else {
                $this->db->prepare('UPDATE budgets SET category_id=?, description=?, amount=?, start_date=?, end_date=? WHERE id=? AND user_id=?')
                    ->execute([$category_id, $description, $amount, $start_date, $end_date, $id, $uid]);
                redirect('budgets');
            }
        }
        $cats = $this->mine("SELECT id,name FROM categories WHERE user_id=? AND type='expense' ORDER BY name", [$uid]);
        require __DIR__ . '/../views/budgets/edit.php';
    }

    public function delete(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $id = (int)($_GET['id'] ?? 0);
        $this->db->prepare('DELETE FROM budgets WHERE id=? AND user_id=?')->execute([$id, $uid]);
        redirect('budgets');
    }

    private function mine(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetchAll(PDO::FETCH_ASSOC); }
    private function one(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetch(PDO::FETCH_ASSOC); }
    private function scalar(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetchColumn(); }
}
