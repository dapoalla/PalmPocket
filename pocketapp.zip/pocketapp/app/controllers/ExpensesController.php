<?php
namespace App\Controllers;

use App\Core\Auth;
use PDO;

class ExpensesController {
    private PDO $db; private Auth $auth;
    public function __construct(PDO $pdo, Auth $auth){ $this->db=$pdo; $this->auth=$auth; }

    public function index(): void {
        $uid = $this->auth->user()['id'];
        $stmt = $this->db->prepare("SELECT e.*, c.name AS category, w.name AS wallet FROM expenses e
            LEFT JOIN categories c ON c.id = e.category_id
            INNER JOIN wallets w ON w.id = e.wallet_id
            WHERE e.user_id = ? ORDER BY e.date DESC, e.id DESC LIMIT 500");
        $stmt->execute([$uid]);
        $expenses = $stmt->fetchAll(PDO::FETCH_ASSOC);
        require __DIR__ . '/../views/expenses/index.php';
    }

    public function create(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $description = trim($_POST['description'] ?? '');
            $amount = (float)($_POST['amount'] ?? 0);
            $wallet_id = (int)($_POST['wallet_id'] ?? 0);
            $category_id = !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null;
            $date = $_POST['date'] ?? date('Y-m-d');
            $note = trim($_POST['note'] ?? '');
            $repeat = !empty($_POST['repeat']) ? 1 : 0;
            $loan_given = !empty($_POST['loan_given']) ? 1 : 0;
            $loan_party = $loan_given ? trim($_POST['loan_party'] ?? '') : null;
            $loan_due = $loan_given && !empty($_POST['loan_due']) ? $_POST['loan_due'] : null;
            $receipt_path = null;

            if (!empty($_FILES['receipt']['name']) && is_uploaded_file($_FILES['receipt']['tmp_name'])) {
                $ext = strtolower(pathinfo($_FILES['receipt']['name'], PATHINFO_EXTENSION));
                $allowed = ['jpg','jpeg','png','gif','pdf','webp'];
                if (!in_array($ext, $allowed, true)) { $ext = 'bin'; }
                @mkdir(RECEIPTS_DIR, 0755, true);
                $fname = uniqid('rcp_') . '.' . $ext;
                $dest = rtrim(RECEIPTS_DIR, '/\\') . DIRECTORY_SEPARATOR . $fname;
                if (!move_uploaded_file($_FILES['receipt']['tmp_name'], $dest)) { $dest = null; }
                if ($dest) { $receipt_path = 'uploads/receipts/' . $fname; }
            }

            $this->db->beginTransaction();
            try {
                $ins = $this->db->prepare('INSERT INTO expenses(user_id, wallet_id, category_id, description, loan_given, loan_party, loan_due, amount, date, note, receipt_path, repeat_toggle) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
                $ins->execute([$uid, $wallet_id, $category_id, $description, $loan_given, $loan_party, $loan_due, $amount, $date, $note, $receipt_path, $repeat]);
                $updW = $this->db->prepare('UPDATE wallets SET balance = balance - ? WHERE id = ? AND user_id = ?');
                $updW->execute([$amount, $wallet_id, $uid]);
                $this->db->commit();
                redirect('expenses');
            } catch (\Throwable $e) {
                $this->db->rollBack();
                $error = $e->getMessage();
            }
        }
        $wallets = $this->mine('SELECT id,name FROM wallets WHERE user_id=?', [$uid]);
        $cats = $this->mine("SELECT id,name FROM categories WHERE user_id=? AND type='expense' AND parent_id IS NOT NULL ORDER BY name", [$uid]);
        require __DIR__ . '/../views/expenses/create.php';
    }

    public function edit(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $id = (int)($_GET['id'] ?? 0);
        $exp = $this->one('SELECT * FROM expenses WHERE id=? AND user_id=?', [$id, $uid]);
        if (!$exp) { http_response_code(404); exit('Not found'); }
        $error = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $amount = (float)($_POST['amount'] ?? 0);
            $wallet_id = (int)($_POST['wallet_id'] ?? 0);
            $category_id = !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null;
            $date = $_POST['date'] ?? date('Y-m-d');
            $note = trim($_POST['note'] ?? '');
            $repeat = !empty($_POST['repeat']) ? 1 : 0;
            $description = trim($_POST['description'] ?? $exp['description']);
            $loan_given = !empty($_POST['loan_given']) ? 1 : 0;
            $loan_party = $loan_given ? trim($_POST['loan_party'] ?? ($exp['loan_party'] ?? '')) : null;
            $loan_due = $loan_given && !empty($_POST['loan_due']) ? $_POST['loan_due'] : ($exp['loan_due'] ?? null);
            $receipt_path = $exp['receipt_path'];

            $this->db->beginTransaction();
            try {
                // adjust wallet balances: revert old amount to old wallet, then deduct new amount from new wallet
                $this->db->prepare('UPDATE wallets SET balance=balance+? WHERE id=? AND user_id=?')->execute([(float)$exp['amount'], (int)$exp['wallet_id'], $uid]);

                if (!empty($_FILES['receipt']['name']) && is_uploaded_file($_FILES['receipt']['tmp_name'])) {
                    if ($receipt_path && file_exists(dirname(__DIR__,2) . '/' . $receipt_path)) @unlink(dirname(__DIR__,2) . '/' . $receipt_path);
                    $ext = strtolower(pathinfo($_FILES['receipt']['name'], PATHINFO_EXTENSION));
                    $allowed = ['jpg','jpeg','png','gif','pdf','webp'];
                    if (!in_array($ext, $allowed, true)) { $ext = 'bin'; }
                    @mkdir(RECEIPTS_DIR, 0755, true);
                    $fname = uniqid('rcp_') . '.' . $ext;
                    $dest = rtrim(RECEIPTS_DIR, '/\\') . DIRECTORY_SEPARATOR . $fname;
                    if (move_uploaded_file($_FILES['receipt']['tmp_name'], $dest)) {
                        $receipt_path = 'uploads/receipts/' . $fname;
                    }
                }

                $this->db->prepare('UPDATE expenses SET wallet_id=?, category_id=?, description=?, loan_given=?, loan_party=?, loan_due=?, amount=?, date=?, note=?, receipt_path=?, repeat_toggle=? WHERE id=? AND user_id=?')
                    ->execute([$wallet_id, $category_id, $description, $loan_given, $loan_party, $loan_due, $amount, $date, $note, $receipt_path, $repeat, $id, $uid]);
                $this->db->prepare('UPDATE wallets SET balance=balance-? WHERE id=? AND user_id=?')->execute([$amount, $wallet_id, $uid]);
                $this->db->commit();
                redirect('expenses');
            } catch (\Throwable $e) {
                $this->db->rollBack();
                $error = $e->getMessage();
            }
        }
        $wallets = $this->mine('SELECT id,name FROM wallets WHERE user_id=?', [$uid]);
        $cats = $this->mine("SELECT id,name FROM categories WHERE user_id=? AND type='expense' AND parent_id IS NOT NULL ORDER BY name", [$uid]);
        require __DIR__ . '/../views/expenses/edit.php';
    }

    public function delete(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $id = (int)($_GET['id'] ?? 0);
        $exp = $this->one('SELECT * FROM expenses WHERE id=? AND user_id=?', [$id, $uid]);
        if (!$exp) { redirect('expenses'); }
        $this->db->beginTransaction();
        try {
            $this->db->prepare('DELETE FROM expenses WHERE id=? AND user_id=?')->execute([$id, $uid]);
            $this->db->prepare('UPDATE wallets SET balance=balance+? WHERE id=? AND user_id=?')->execute([(float)$exp['amount'], (int)$exp['wallet_id'], $uid]);
            if (!empty($exp['receipt_path'])) {
                $full = dirname(__DIR__,2) . '/' . $exp['receipt_path'];
                if (file_exists($full)) @unlink($full);
            }
            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollBack();
        }
        redirect('expenses');
    }

    public function sampleCsv(): void {
        $filename = 'expenses_sample.csv';
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename=' . $filename);
        $out = fopen('php://output', 'w');
        fputcsv($out, ['date','wallet','category','description','amount','note']);
        fputcsv($out, [date('Y-m-d'),'Cash','Food','Lunch', '3500','Jollof Rice']);
        fputcsv($out, [date('Y-m-d'),'Bank Account','Transport','Ride', '1200','Bolt']);
        fclose($out);
        exit;
    }

    public function importCsv(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_FILES['csv']['tmp_name'])) { redirect('expenses'); }
        $fh = fopen($_FILES['csv']['tmp_name'], 'r');
        if (!$fh) { redirect('expenses'); }
        $header = fgetcsv($fh);
        $map = array_map('strtolower', $header ?: []);
        $idx = [
            'date' => array_search('date', $map, true),
            'wallet' => array_search('wallet', $map, true),
            'category' => array_search('category', $map, true),
            'description' => array_search('description', $map, true),
            'amount' => array_search('amount', $map, true),
            'note' => array_search('note', $map, true),
        ];
        while (($row = fgetcsv($fh)) !== false) {
            $date = $idx['date']!==false ? ($row[$idx['date']] ?? date('Y-m-d')) : date('Y-m-d');
            $walletName = trim((string)($idx['wallet']!==false ? ($row[$idx['wallet']] ?? '') : ''));
            $catName = trim((string)($idx['category']!==false ? ($row[$idx['category']] ?? '') : ''));
            $desc = trim((string)($idx['description']!==false ? ($row[$idx['description']] ?? '') : ''));
            $amount = (float)($idx['amount']!==false ? ($row[$idx['amount']] ?? 0) : 0);
            $note = trim((string)($idx['note']!==false ? ($row[$idx['note']] ?? '') : ''));
            if ($amount <= 0 || $desc==='') continue;
            // ensure wallet
            $wal = $this->one('SELECT id FROM wallets WHERE user_id=? AND name=?', [$uid, $walletName]);
            if (!$wal) {
                $this->db->prepare("INSERT INTO wallets(user_id,name,type,balance) VALUES (?,?,?,0)")->execute([$uid, $walletName ?: 'Imported', 'cash']);
                $wallet_id = (int)$this->db->lastInsertId();
            } else { $wallet_id = (int)$wal['id']; }
            // ensure category
            $cat = $this->one("SELECT id FROM categories WHERE user_id=? AND name=? AND type='expense'", [$uid, $catName]);
            if (!$cat) {
                $this->db->prepare("INSERT INTO categories(user_id,name,type) VALUES (?,?,?)")->execute([$uid, $catName ?: 'Imported', 'expense']);
                $category_id = (int)$this->db->lastInsertId();
            } else { $category_id = (int)$cat['id']; }
            // insert expense and update wallet
            $this->db->beginTransaction();
            try {
                $this->db->prepare('INSERT INTO expenses(user_id,wallet_id,category_id,description,amount,date,note,repeat_toggle) VALUES (?,?,?,?,?,?,?,0)')
                    ->execute([$uid,$wallet_id,$category_id,$desc,$amount,$date,$note]);
                $this->db->prepare('UPDATE wallets SET balance=balance-? WHERE id=? AND user_id=?')->execute([$amount,$wallet_id,$uid]);
                $this->db->commit();
            } catch (\Throwable $e) {
                $this->db->rollBack();
                // continue next row
            }
        }
        fclose($fh);
        redirect('expenses');
    }

    private function mine(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetchAll(PDO::FETCH_ASSOC); }
    private function one(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetch(PDO::FETCH_ASSOC); }
}
