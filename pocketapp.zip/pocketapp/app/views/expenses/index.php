<?php require __DIR__ . '/../layout/header.php'; ?>
<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <h3 class="m-0">Expenses</h3>
  <div class="d-flex align-items-center gap-2">
    <form method="post" action="index.php?route=expense_import" enctype="multipart/form-data" class="d-flex align-items-center gap-2">
      <?= csrf_field() ?>
      <input type="file" name="csv" accept="text/csv" class="form-control form-control-sm" required>
      <button class="btn btn-sm btn-outline-secondary" type="submit">Import CSV</button>
    </form>
    <a class="btn btn-sm btn-outline-info" href="index.php?route=expense_sample_csv">Download Sample CSV</a>
    <a href="index.php?route=expense_create" class="btn btn-sm btn-primary">Add Expense</a>
  </div>
</div>
<div class="card"><div class="card-body p-0">
  <div class="table-responsive">
    <table class="table table-striped mb-0">
      <thead><tr>
        <th>Date</th><th>Description</th><th>Category</th><th>Wallet</th><th>Amount</th><th>Note</th><th>Receipt</th><th></th>
      </tr></thead>
      <tbody>
      <?php foreach ($expenses as $x): ?>
        <tr>
          <td><?= e($x['date']) ?></td>
          <td><?= e($x['description']) ?></td>
          <td><?= e($x['category'] ?? '-') ?></td>
          <td><?= e($x['wallet']) ?></td>
          <td>₦<?= number_format((float)$x['amount'], 2) ?></td>
          <td><?= e($x['note'] ?? '') ?></td>
          <td><?php if (!empty($x['receipt_path'])): ?><a href="<?= e($x['receipt_path']) ?>" target="_blank">View</a><?php endif; ?></td>
          <td class="text-end">
            <a class="btn btn-sm btn-outline-secondary" href="index.php?route=expense_edit&id=<?= (int)$x['id'] ?>">Edit</a>
            <form method="post" action="index.php?route=expense_delete&id=<?= (int)$x['id'] ?>" class="d-inline" onsubmit="return confirm('Delete expense?');">
              <?= csrf_field() ?>
              <button class="btn btn-sm btn-outline-danger">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div></div>
<?php require __DIR__ . '/../layout/footer.php'; ?>
