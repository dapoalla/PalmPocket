<?php
$userName = $_SESSION['user_name'] ?? null;
$theme = $_SESSION['theme'] ?? ($_COOKIE['theme'] ?? 'dark');
$theme = in_array($theme, ['dark','light'], true) ? $theme : 'dark';
?>
<!doctype html>
<html lang="en" data-bs-theme="<?= e($theme) ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e(APP_NAME) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="public/assets/css/style.css">
</head>
<body>
<?php if ($userName): ?>
  <nav class="navbar navbar-expand-md border-bottom sticky-top bg-body">
    <div class="container-fluid">
      <button class="btn btn-outline-secondary d-md-none me-2" id="sidebarToggle" type="button" aria-label="Toggle navigation">☰</button>
      <a class="navbar-brand fw-semibold" href="index.php?route=dashboard"><?= e(APP_NAME) ?></a>
      <div class="ms-auto small text-muted d-none d-md-block">v<?= defined('APP_VERSION')? e(APP_VERSION):'1.0.0' ?></div>
    </div>
  </nav>
<?php endif; ?>
<div class="d-flex">
  <?php if ($userName): require __DIR__ . '/sidebar.php'; endif; ?>
  <main class="flex-grow-1 p-3 container-fluid">
