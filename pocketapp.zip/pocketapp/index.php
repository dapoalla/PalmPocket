<?php
// Personal Finance Manager - Front Controller & Simple Router
// Loads config, initializes session, and routes to controllers

declare(strict_types=1);

// Redirect to installer if no config yet
if (!file_exists(__DIR__ . '/config.php')) {
    header('Location: installer/index.php');
    exit;
}

require __DIR__ . '/config.php';
require __DIR__ . '/app/helpers.php';
require __DIR__ . '/app/core/Database.php';
require __DIR__ . '/app/core/Auth.php';

session_start();

use App\Core\Auth;

$auth = new Auth($pdo);

$route = $_GET['route'] ?? 'dashboard';

// Public routes
if (in_array($route, ['login','forgot','reset'])) {
    require __DIR__ . '/app/controllers/AuthController.php';
    $controller = new App\Controllers\AuthController($pdo, $auth);
    switch ($route) {
        case 'login':
            $controller->login();
            break;
        case 'forgot':
            $controller->forgot();
            break;
        case 'reset':
            $controller->reset();
            break;
    }
    exit;
}

// Authenticated routes
if (!$auth->check()) {
    redirect('login');
}

require __DIR__ . '/app/controllers/DashboardController.php';
$controller = new App\Controllers\DashboardController($pdo, $auth);

switch ($route) {
    case 'dashboard':
        $controller->index();
        break;
    case 'expenses':
    case 'expense_create':
    case 'expense_edit':
    case 'expense_delete':
    case 'expense_import':
    case 'expense_sample_csv':
        require __DIR__ . '/app/controllers/ExpensesController.php';
        $exp = new App\Controllers\ExpensesController($pdo, $auth);
        if ($route === 'expenses') $exp->index();
        if ($route === 'expense_create') $exp->create();
        if ($route === 'expense_edit') $exp->edit();
        if ($route === 'expense_delete') $exp->delete();
        if ($route === 'expense_import') $exp->importCsv();
        if ($route === 'expense_sample_csv') $exp->sampleCsv();
        break;
    case 'incomes':
    case 'income_create':
    case 'income_edit':
    case 'income_delete':
        require __DIR__ . '/app/controllers/IncomesController.php';
        $inc = new App\Controllers\IncomesController($pdo, $auth);
        if ($route === 'incomes') $inc->index();
        if ($route === 'income_create') $inc->create();
        if ($route === 'income_edit') $inc->edit();
        if ($route === 'income_delete') $inc->delete();
        break;
    case 'categories':
    case 'category_create':
    case 'category_edit':
    case 'category_delete':
        require __DIR__ . '/app/controllers/CategoriesController.php';
        $cat = new App\Controllers\CategoriesController($pdo, $auth);
        if ($route === 'categories') $cat->index();
        if ($route === 'category_create') $cat->create();
        if ($route === 'category_edit') $cat->edit();
        if ($route === 'category_delete') $cat->delete();
        break;
    case 'wallets':
    case 'wallet_create':
    case 'wallet_edit':
    case 'wallet_delete':
    case 'wallet_transfer':
        require __DIR__ . '/app/controllers/WalletsController.php';
        $wal = new App\Controllers\WalletsController($pdo, $auth);
        if ($route === 'wallets') $wal->index();
        if ($route === 'wallet_create') $wal->create();
        if ($route === 'wallet_edit') $wal->edit();
        if ($route === 'wallet_delete') $wal->delete();
        if ($route === 'wallet_transfer') $wal->transfer();
        break;
    case 'budgets':
    case 'budget_create':
    case 'budget_edit':
    case 'budget_delete':
        require __DIR__ . '/app/controllers/BudgetsController.php';
        $bud = new App\Controllers\BudgetsController($pdo, $auth);
        if ($route === 'budgets') $bud->index();
        if ($route === 'budget_create') $bud->create();
        if ($route === 'budget_edit') $bud->edit();
        if ($route === 'budget_delete') $bud->delete();
        break;
    
    case 'goals':
    case 'goal_create':
    case 'goal_edit':
    case 'goal_delete':
    case 'goal_add_saving':
        require __DIR__ . '/app/controllers/GoalsController.php';
        $go = new App\Controllers\GoalsController($pdo, $auth);
        if ($route === 'goals') $go->index();
        if ($route === 'goal_create') $go->create();
        if ($route === 'goal_edit') $go->edit();
        if ($route === 'goal_delete') $go->delete();
        if ($route === 'goal_add_saving') $go->addSaving();
        break;
    case 'loans':
    case 'loan_settle_given':
    case 'loan_settle_taken':
        require __DIR__ . '/app/controllers/LoansController.php';
        $ln = new App\Controllers\LoansController($pdo, $auth);
        if ($route === 'loans') $ln->index();
        if ($route === 'loan_settle_given') $ln->settleGiven();
        if ($route === 'loan_settle_taken') $ln->settleTaken();
        break;
    case 'reports':
    case 'report_csv':
        require __DIR__ . '/app/controllers/ReportsController.php';
        $rep = new App\Controllers\ReportsController($pdo, $auth);
        if ($route === 'reports') $rep->index();
        if ($route === 'report_csv') $rep->csv();
        break;
    case 'backups':
    case 'backup_create':
    case 'backup_download':
    case 'backup_import':
        require __DIR__ . '/app/controllers/BackupsController.php';
        $bak = new App\Controllers\BackupsController($pdo, $auth);
        if ($route === 'backups') $bak->index();
        if ($route === 'backup_create') $bak->create();
        if ($route === 'backup_download') $bak->download();
        if ($route === 'backup_import') $bak->import();
        break;
    case 'settings':
    case 'settings_save_theme':
    case 'settings_change_password':
        require __DIR__ . '/app/controllers/SettingsController.php';
        $set = new App\Controllers\SettingsController($pdo, $auth);
        if ($route === 'settings') $set->index();
        if ($route === 'settings_save_theme') $set->saveTheme();
        if ($route === 'settings_change_password') $set->changePassword();
        break;
    case 'logout':
        $auth->logout();
        redirect('login');
        break;
    default:
        http_response_code(404);
        echo 'Page not found';
}
