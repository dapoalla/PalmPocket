<?php require __DIR__ . '/../layout/header.php'; ?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h3>Wallets</h3>
  <div class="d-flex gap-2">
    <a href="index.php?route=wallet_transfer" class="btn btn-outline-primary">Transfer</a>
    <a href="index.php?route=wallet_create" class="btn btn-primary">Add Wallet</a>
  </div>
</div>
<div class="row g-3 mb-4">
  <?php foreach ($wallets as $w): ?>
    <div class="col-md-4">
      <div class="card h-100"><div class="card-body d-flex flex-column">
        <div class="d-flex justify-content-between align-items-center">
          <div class="fw-semibold"><?= e($w['name']) ?></div>
          <span class="badge bg-secondary text-uppercase"><?= e($w['type']) ?></span>
        </div>
        <div class="display-6 mt-2">₦<?= number_format((float)$w['balance'], 2) ?></div>
        <div class="mt-auto d-flex gap-2">
          <a class="btn btn-sm btn-outline-secondary" href="index.php?route=wallet_edit&id=<?= (int)$w['id'] ?>">Edit</a>
          <form method="post" action="index.php?route=wallet_delete&id=<?= (int)$w['id'] ?>" onsubmit="return confirm('Delete wallet? This may affect balances.');">
            <?= csrf_field() ?>
            <button class="btn btn-sm btn-outline-danger">Delete</button>
          </form>
        </div>
      </div></div>
    </div>
  <?php endforeach; ?>
</div>

<div class="card"><div class="card-body p-0">
  <h6 class="p-3 m-0">Recent Transfers</h6>
  <div class="table-responsive">
    <table class="table table-striped mb-0">
      <thead><tr>
        <th>Date</th><th>From</th><th>To</th><th>Amount</th><th>Note</th>
      </tr></thead>
      <tbody>
      <?php foreach ($transfers as $t): ?>
        <tr>
          <td><?= e($t['date']) ?></td>
          <td><?= e($t['from_wallet']) ?></td>
          <td><?= e($t['to_wallet']) ?></td>
          <td>₦<?= number_format((float)$t['amount'], 2) ?></td>
          <td><?= e($t['note'] ?? '') ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div></div>
<?php require __DIR__ . '/../layout/footer.php'; ?>
