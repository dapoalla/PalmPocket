<?php require __DIR__ . '/../layout/header.php'; ?>
<h3 class="mb-3">Edit Expense</h3>
<?php if (!empty($error)): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<form method="post" enctype="multipart/form-data">
  <?= csrf_field() ?>
  <div class="row g-3">
    <div class="col-12">
      <label class="form-label">Description</label>
      <input class="form-control" name="description" value="<?= e($exp['description']) ?>" required>
    </div>
    <div class="col-12">
      <div class="form-check">
        <input class="form-check-input" type="checkbox" name="loan_given" id="loan_given" <?= !empty($exp['loan_given'])?'checked':'' ?>>
        <label class="form-check-label" for="loan_given">This expense is a loan I gave to someone</label>
      </div>
    </div>
    <div class="col-md-6">
      <label class="form-label">Debtor Name</label>
      <input class="form-control" name="loan_party" value="<?= e((string)($exp['loan_party'] ?? '')) ?>" placeholder="Who owes you?">
    </div>
    <div class="col-md-6">
      <label class="form-label">Due Date</label>
      <input class="form-control" type="date" name="loan_due" value="<?= e((string)($exp['loan_due'] ?? '')) ?>">
    </div>
    <div class="col-md-3">
      <label class="form-label">Amount</label>
      <input class="form-control" type="number" step="0.01" name="amount" value="<?= e((string)$exp['amount']) ?>" required>
    </div>
    <div class="col-md-3">
      <label class="form-label">Wallet</label>
      <select class="form-select" name="wallet_id" required>
        <?php foreach ($wallets as $w): $sel = $w['id']==$exp['wallet_id'] ? 'selected' : ''; ?>
          <option value="<?= (int)$w['id'] ?>" <?= $sel ?>><?= e($w['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3">
      <label class="form-label">Category</label>
      <select class="form-select" name="category_id">
        <option value="">- none -</option>
        <?php foreach ($cats as $c): $sel = $c['id']==$exp['category_id'] ? 'selected' : ''; ?>
          <option value="<?= (int)$c['id'] ?>" <?= $sel ?>><?= e($c['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3">
      <label class="form-label">Date</label>
      <input class="form-control" type="date" name="date" value="<?= e($exp['date']) ?>" required>
    </div>
    <div class="col-12">
      <label class="form-label">Note</label>
      <input class="form-control" name="note" value="<?= e($exp['note']) ?>">
    </div>
    <div class="col-md-6">
      <label class="form-label">Receipt (upload to replace)</label>
      <input class="form-control" type="file" name="receipt" accept="image/*,application/pdf">
      <?php if (!empty($exp['receipt_path'])): ?><div class="form-text">Current: <a href="<?= e($exp['receipt_path']) ?>" target="_blank">View</a></div><?php endif; ?>
    </div>
    <div class="col-md-3 form-check mt-4">
      <input class="form-check-input" type="checkbox" name="repeat" id="repeat" <?= $exp['repeat_toggle'] ? 'checked' : '' ?>>
      <label class="form-check-label" for="repeat">Repeat</label>
    </div>
  </div>
  <div class="mt-3 d-flex gap-2">
    <button class="btn btn-primary" type="submit">Update</button>
    <a class="btn btn-secondary" href="index.php?route=expenses">Cancel</a>
  </div>
</form>
<?php require __DIR__ . '/../layout/footer.php'; ?>
