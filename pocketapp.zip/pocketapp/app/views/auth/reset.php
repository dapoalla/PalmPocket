<?php require __DIR__ . '/../layout/header.php'; ?>
<div class="container" style="max-width:480px;">
  <h3 class="mb-3">Reset Password</h3>
  <?php if (!empty($status)): ?>
    <div class="alert alert-info"><?= e($status) ?></div>
  <?php endif; ?>
  <form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="token" value="<?= e($token) ?>">
    <div class="mb-3">
      <label class="form-label">New Password</label>
      <input type="password" name="password" class="form-control" required>
    </div>
    <button class="btn btn-primary" type="submit">Reset</button>
  </form>
</div>
<?php require __DIR__ . '/../layout/footer.php'; ?>
