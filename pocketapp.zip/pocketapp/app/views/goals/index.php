<?php require __DIR__ . '/../layout/header.php'; ?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h3>Goals</h3>
  <a href="index.php?route=goal_create" class="btn btn-primary">Add Goal</a>
  </div>

<div class="row g-3 mb-3">
  <div class="col-md-4">
    <div class="card"><div class="card-body">
      <div class="text-muted">Wishlist Total</div>
      <div class="h4">₦<?= number_format((float)$wishlistTotal, 2) ?></div>
    </div></div>
  </div>
  <div class="col-md-4">
    <div class="card"><div class="card-body">
      <div class="text-muted">Savings Target</div>
      <div class="h4">₦<?= number_format((float)($savingTotals['target'] ?? 0), 2) ?></div>
    </div></div>
  </div>
  <div class="col-md-4">
    <div class="card"><div class="card-body">
      <div class="text-muted">Savings Achieved</div>
      <div class="h4">₦<?= number_format((float)($savingTotals['saved'] ?? 0), 2) ?></div>
    </div></div>
  </div>
</div>

<h6 class="mb-2">Saving Goals</h6>
<div class="row g-3 mb-4">
<?php foreach ($rows as $g): if ($g['type'] !== 'saving') continue; ?>
  <div class="col-md-6">
    <div class="card h-100"><div class="card-body d-flex flex-column">
      <div class="d-flex justify-content-between align-items-start">
        <div>
          <div class="fw-semibold"><?= e($g['title']) ?></div>
          <?php if (!empty($g['deadline'])): ?><div class="text-muted small">Due: <?= e($g['deadline']) ?></div><?php endif; ?>
        </div>
        <div class="text-end">
          <div class="small text-muted">Target</div>
          <div>₦<?= number_format((float)$g['target_amount'], 2) ?></div>
        </div>
      </div>
      <div class="mt-3">
        <div class="small text-muted">Saved: ₦<?= number_format((float)$g['saved_amount'], 2) ?></div>
        <div class="progress" role="progressbar" aria-valuenow="<?= (int)$g['percent'] ?>" aria-valuemin="0" aria-valuemax="100">
          <div class="progress-bar" style="width: <?= (int)$g['percent'] ?>%"><?= (int)$g['percent'] ?>%</div>
        </div>
      </div>
      <div class="mt-auto d-flex gap-2">
        <a class="btn btn-sm btn-outline-primary" href="index.php?route=goal_add_saving&id=<?= (int)$g['id'] ?>">Add Saving</a>
        <a class="btn btn-sm btn-outline-secondary" href="index.php?route=goal_edit&id=<?= (int)$g['id'] ?>">Edit</a>
        <form method="post" action="index.php?route=goal_delete&id=<?= (int)$g['id'] ?>" onsubmit="return confirm('Delete goal?');">
          <?= csrf_field() ?>
          <button class="btn btn-sm btn-outline-danger">Delete</button>
        </form>
      </div>
    </div></div>
  </div>
<?php endforeach; ?>
</div>

<h6 class="mb-2">Wishlist</h6>
<div class="row g-3">
<?php foreach ($rows as $g): if ($g['type'] !== 'wishlist') continue; ?>
  <div class="col-md-6">
    <div class="card h-100"><div class="card-body d-flex flex-column">
      <div class="d-flex justify-content-between align-items-start">
        <div class="fw-semibold"><?= e($g['title']) ?></div>
        <div class="text-end">
          <div class="small text-muted">Price</div>
          <div>₦<?= number_format((float)$g['wishlist_price'], 2) ?></div>
        </div>
      </div>
      <div class="mt-auto d-flex gap-2">
        <a class="btn btn-sm btn-outline-secondary" href="index.php?route=goal_edit&id=<?= (int)$g['id'] ?>">Edit</a>
        <form method="post" action="index.php?route=goal_delete&id=<?= (int)$g['id'] ?>" onsubmit="return confirm('Delete goal?');">
          <?= csrf_field() ?>
          <button class="btn btn-sm btn-outline-danger">Delete</button>
        </form>
      </div>
    </div></div>
  </div>
<?php endforeach; ?>
</div>
<?php require __DIR__ . '/../layout/footer.php'; ?>
