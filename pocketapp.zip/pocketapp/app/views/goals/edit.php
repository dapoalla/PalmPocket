<?php require __DIR__ . '/../layout/header.php'; ?>
<h3 class="mb-3">Edit Goal</h3>
<?php if (!empty($error)): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<form method="post">
  <?= csrf_field() ?>
  <div class="row g-3">
    <div class="col-md-3">
      <label class="form-label">Type</label>
      <select class="form-select" name="type">
        <option value="saving" <?= $goal['type']==='saving'?'selected':'' ?>>Saving Goal</option>
        <option value="wishlist" <?= $goal['type']==='wishlist'?'selected':'' ?>>Wishlist Item</option>
      </select>
    </div>
    <div class="col-md-6">
      <label class="form-label">Title</label>
      <input class="form-control" name="title" value="<?= e($goal['title']) ?>" required>
    </div>
    <div class="col-md-3">
      <label class="form-label">Target Amount</label>
      <input class="form-control" type="number" step="0.01" name="target_amount" value="<?= e((string)$goal['target_amount']) ?>" required>
    </div>
    <div class="col-md-3">
      <label class="form-label">Deadline</label>
      <input class="form-control" type="date" name="deadline" value="<?= e((string)$goal['deadline']) ?>">
    </div>
    <div class="col-md-3">
      <label class="form-label">Wishlist Price (optional)</label>
      <input class="form-control" type="number" step="0.01" name="wishlist_price" value="<?= e((string)$goal['wishlist_price']) ?>">
    </div>
  </div>
  <div class="form-text mt-2">For Wishlist, the wishlist price will be used as target amount. Savings can be added only to Saving Goals.</div>
  <div class="mt-3 d-flex gap-2">
    <button class="btn btn-primary" type="submit">Update</button>
    <a class="btn btn-secondary" href="index.php?route=goals">Cancel</a>
  </div>
</form>
<?php require __DIR__ . '/../layout/footer.php'; ?>
