<aside id="appSidebar" class="p-3 border-end sidebar d-none d-md-block" style="width:260px; min-height:100vh;">
  <div class="mb-3 fw-bold"><a class="text-decoration-none" href="index.php?route=dashboard"><?= e(APP_NAME) ?></a></div>
  <nav class="nav flex-column gap-1">
    <a class="nav-link" href="index.php?route=dashboard">Dashboard</a>
    <a class="nav-link" href="index.php?route=expenses">Expenses</a>
    <a class="nav-link" href="index.php?route=incomes">Income</a>
    <a class="nav-link" href="index.php?route=categories">Categories</a>
    <a class="nav-link" href="index.php?route=wallets">Wallets</a>
    <a class="nav-link" href="index.php?route=budgets">Budgets</a>
    <a class="nav-link" href="index.php?route=goals">Goals</a>
    <a class="nav-link" href="index.php?route=loans">Loans</a>
    <a class="nav-link" href="index.php?route=reports">Reports</a>
    <a class="nav-link" href="index.php?route=settings">Settings</a>
    <a class="nav-link text-danger" href="index.php?route=logout">Logout</a>
  </nav>
</aside>
