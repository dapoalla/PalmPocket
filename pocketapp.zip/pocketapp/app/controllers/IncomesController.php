<?php
namespace App\Controllers;

use App\Core\Auth;
use PDO;

class IncomesController {
    private PDO $db; private Auth $auth;
    public function __construct(PDO $pdo, Auth $auth){ $this->db=$pdo; $this->auth=$auth; }

    public function index(): void {
        $uid = $this->auth->user()['id'];
        $stmt = $this->db->prepare("SELECT i.*, c.name AS category, w.name AS wallet FROM incomes i
            LEFT JOIN categories c ON c.id = i.category_id
            INNER JOIN wallets w ON w.id = i.wallet_id
            WHERE i.user_id = ? ORDER BY i.date DESC, i.id DESC LIMIT 500");
        $stmt->execute([$uid]);
        $incomes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        require __DIR__ . '/../views/incomes/index.php';
    }

    public function create(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $source = trim($_POST['source'] ?? '');
            $amount = (float)($_POST['amount'] ?? 0);
            $wallet_id = (int)($_POST['wallet_id'] ?? 0);
            $category_id = !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null;
            $date = $_POST['date'] ?? date('Y-m-d');
            $note = trim($_POST['note'] ?? '');
            $loan_taken = !empty($_POST['loan_taken']) ? 1 : 0;
            $loan_party = $loan_taken ? trim($_POST['loan_party'] ?? '') : null;
            $loan_due = $loan_taken && !empty($_POST['loan_due']) ? $_POST['loan_due'] : null;
            $loan_taken = !empty($_POST['loan_taken']) ? 1 : 0;
            $loan_party = $loan_taken ? trim($_POST['loan_party'] ?? '') : null;
            $loan_due = $loan_taken && !empty($_POST['loan_due']) ? $_POST['loan_due'] : null;

            $this->db->beginTransaction();
            try {
                $ins = $this->db->prepare('INSERT INTO incomes(user_id, wallet_id, category_id, source, loan_taken, loan_party, loan_due, amount, date, note) VALUES (?,?,?,?,?,?,?,?,?,?)');
                $ins->execute([$uid, $wallet_id, $category_id, $source, $loan_taken, $loan_party, $loan_due, $amount, $date, $note]);
                $updW = $this->db->prepare('UPDATE wallets SET balance = balance + ? WHERE id = ? AND user_id = ?');
                $updW->execute([$amount, $wallet_id, $uid]);
                $this->db->commit();
                redirect('incomes');
            } catch (\Throwable $e) {
                $this->db->rollBack();
                $error = $e->getMessage();
            }
        }
        $wallets = $this->mine('SELECT id,name FROM wallets WHERE user_id=?', [$uid]);
        $cats = $this->mine("SELECT id,name FROM categories WHERE user_id=? AND type='income' AND parent_id IS NOT NULL ORDER BY name", [$uid]);
        require __DIR__ . '/../views/incomes/create.php';
    }

    public function edit(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $id = (int)($_GET['id'] ?? 0);
        $inc = $this->one('SELECT * FROM incomes WHERE id=? AND user_id=?', [$id, $uid]);
        if (!$inc) { http_response_code(404); exit('Not found'); }
        $error = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $amount = (float)($_POST['amount'] ?? 0);
            $wallet_id = (int)($_POST['wallet_id'] ?? 0);
            $category_id = !empty($_POST['category_id']) ? (int)$_POST['category_id'] : null;
            $date = $_POST['date'] ?? date('Y-m-d');
            $source = trim($_POST['source'] ?? '');
            $note = trim($_POST['note'] ?? '');

            $this->db->beginTransaction();
            try {
                // revert old amount from old wallet, then add new amount to new wallet
                $this->db->prepare('UPDATE wallets SET balance=balance-? WHERE id=? AND user_id=?')->execute([(float)$inc['amount'], (int)$inc['wallet_id'], $uid]);
                $this->db->prepare('UPDATE incomes SET wallet_id=?, category_id=?, source=?, loan_taken=?, loan_party=?, loan_due=?, amount=?, date=?, note=? WHERE id=? AND user_id=?')
                    ->execute([$wallet_id, $category_id, $source, $loan_taken, $loan_party, $loan_due, $amount, $date, $note, $id, $uid]);
                $this->db->prepare('UPDATE wallets SET balance=balance+? WHERE id=? AND user_id=?')->execute([$amount, $wallet_id, $uid]);
                $this->db->commit();
                redirect('incomes');
            } catch (\Throwable $e) {
                $this->db->rollBack();
                $error = $e->getMessage();
            }
        }
        $wallets = $this->mine('SELECT id,name FROM wallets WHERE user_id=?', [$uid]);
        $cats = $this->mine("SELECT id,name FROM categories WHERE user_id=? AND type='income' AND parent_id IS NOT NULL ORDER BY name", [$uid]);
        require __DIR__ . '/../views/incomes/edit.php';
    }

    public function delete(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $id = (int)($_GET['id'] ?? 0);
        $inc = $this->one('SELECT * FROM incomes WHERE id=? AND user_id=?', [$id, $uid]);
        if (!$inc) { redirect('incomes'); }
        $this->db->beginTransaction();
        try {
            $this->db->prepare('DELETE FROM incomes WHERE id=? AND user_id=?')->execute([$id, $uid]);
            $this->db->prepare('UPDATE wallets SET balance=balance-? WHERE id=? AND user_id=?')->execute([(float)$inc['amount'], (int)$inc['wallet_id'], $uid]);
            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollBack();
        }
        redirect('incomes');
    }

    private function mine(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetchAll(PDO::FETCH_ASSOC); }
    private function one(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetch(PDO::FETCH_ASSOC); }
}
