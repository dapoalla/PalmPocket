<?php
namespace App\Controllers;

use App\Core\Auth;
use PDO;

class AuthController {
    private PDO $db; private Auth $auth;
    public function __construct(PDO $pdo, Auth $auth){ $this->db=$pdo; $this->auth=$auth; }

    public function login(): void {
        verify_csrf();
        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            if ($this->auth->attempt($email, $password)) {
                redirect('dashboard');
            } else {
                $error = 'Invalid credentials';
            }
        }
        require __DIR__ . '/../views/auth/login.php';
    }

    public function forgot(): void {
        verify_csrf();
        $sent = false; $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $token = bin2hex(random_bytes(32));
            $stmt = $this->db->prepare('UPDATE users SET reset_token = ?, reset_expires = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE email = ?');
            $stmt->execute([$token, $email]);
            $sent = true; // In real deployment, send email with link
        }
        require __DIR__ . '/../views/auth/forgot.php';
    }

    public function reset(): void {
        verify_csrf();
        $token = $_GET['token'] ?? '';
        $status = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $token = $_POST['token'] ?? '';
            $pass = $_POST['password'] ?? '';
            $stmt = $this->db->prepare('SELECT id FROM users WHERE reset_token = ? AND reset_expires >= NOW()');
            $stmt->execute([$token]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($user) {
                $hash = password_hash($pass, PASSWORD_DEFAULT);
                $upd = $this->db->prepare('UPDATE users SET password_hash = ?, reset_token = NULL, reset_expires = NULL WHERE id = ?');
                $upd->execute([$hash, $user['id']]);
                $status = 'Password reset. You can now login.';
            } else {
                $status = 'Invalid or expired reset link.';
            }
        }
        require __DIR__ . '/../views/auth/reset.php';
    }
}
