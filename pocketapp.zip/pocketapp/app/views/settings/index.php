<?php require __DIR__ . '/../layout/header.php'; ?>
<h3 class="mb-3">Settings</h3>
<div class="row g-3">
  <div class="col-md-6">
    <div class="card"><div class="card-body">
      <h6>Appearance</h6>
      <form method="post" action="index.php?route=settings_save_theme" class="d-flex align-items-end gap-2 mt-2">
        <?= csrf_field() ?>
        <div class="flex-grow-1">
          <label class="form-label">Theme</label>
          <select class="form-select" name="theme">
            <option value="light" <?= ($theme==='light')?'selected':'' ?>>Light</option>
            <option value="dark" <?= ($theme==='dark')?'selected':'' ?>>Dark</option>
          </select>
        </div>
        <button class="btn btn-primary" type="submit">Save</button>
      </form>
    </div></div>
  </div>
  <div class="col-md-6">
    <div class="card"><div class="card-body">
      <h6>Change Password</h6>
      <?php if (!empty($ok)): ?><div class="alert alert-success">Password changed.</div><?php endif; ?>
      <?php if (!empty($error)): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
      <form method="post" action="index.php?route=settings_change_password" class="mt-2">
        <?= csrf_field() ?>
        <div class="mb-2">
          <label class="form-label">Current Password</label>
          <input class="form-control" type="password" name="current" required>
        </div>
        <div class="mb-2">
          <label class="form-label">New Password</label>
          <input class="form-control" type="password" name="new" required>
        </div>
        <div class="mb-2">
          <label class="form-label">Confirm New Password</label>
          <input class="form-control" type="password" name="confirm" required>
        </div>
        <button class="btn btn-primary" type="submit">Change Password</button>
      </form>
    </div></div>
  </div>
  <div class="col-md-6">
    <div class="card h-100"><div class="card-body">
      <h6 class="mb-2">About <?= e(APP_NAME) ?></h6>
      <div class="small text-muted mb-2">Version</div>
      <div class="mb-3">v<?= defined('APP_VERSION') ? e(APP_VERSION) : '1.0.0' ?></div>
      <div class="small text-muted mb-2">Features</div>
      <ul class="small m-0">
        <li>Expenses and Incomes with receipts</li>
        <li>Wallets and Transfers</li>
        <li>Budgets (monthly) with notifications</li>
        <li>Goals: Saving and Wishlist</li>
        <li>Loans: Given and Taken, with settlements</li>
        <li>Reports with category pie and transactions list</li>
        <li>Backup and Restore</li>
      </ul>
    </div></div>
  </div>
  <div class="col-md-6">
    <div class="card h-100"><div class="card-body d-flex flex-column">
      <h6 class="mb-2">Backups</h6>
      <div class="text-muted small mb-3">Create and restore backups of your data.</div>
      <div class="mt-auto">
        <a class="btn btn-outline-primary" href="index.php?route=backups">Open Backups</a>
      </div>
    </div></div>
  </div>
</div>
<?php require __DIR__ . '/../layout/footer.php'; ?>
