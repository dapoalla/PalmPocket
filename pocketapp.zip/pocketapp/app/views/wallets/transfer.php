<?php require __DIR__ . '/../layout/header.php'; ?>
<h3 class="mb-3">Transfer Between Wallets</h3>
<?php if (!empty($error)): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<form method="post">
  <?= csrf_field() ?>
  <div class="row g-3">
    <div class="col-md-4">
      <label class="form-label">From Wallet</label>
      <select class="form-select" name="from_wallet_id" required>
        <?php foreach ($wallets as $w): ?><option value="<?= (int)$w['id'] ?>"><?= e($w['name']) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4">
      <label class="form-label">To Wallet</label>
      <select class="form-select" name="to_wallet_id" required>
        <?php foreach ($wallets as $w): ?><option value="<?= (int)$w['id'] ?>"><?= e($w['name']) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4">
      <label class="form-label">Amount</label>
      <input class="form-control" type="number" step="0.01" name="amount" required>
    </div>
    <div class="col-md-4">
      <label class="form-label">Date</label>
      <input class="form-control" type="date" name="date" value="<?= date('Y-m-d') ?>" required>
    </div>
    <div class="col-md-8">
      <label class="form-label">Note</label>
      <input class="form-control" name="note">
    </div>
  </div>
  <div class="mt-3 d-flex gap-2">
    <button class="btn btn-primary" type="submit">Transfer</button>
    <a class="btn btn-secondary" href="index.php?route=wallets">Cancel</a>
  </div>
</form>
<?php require __DIR__ . '/../layout/footer.php'; ?>
