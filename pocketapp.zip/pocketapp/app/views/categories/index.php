<?php require __DIR__ . '/../layout/header.php'; ?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h3>Categories</h3>
  <a href="index.php?route=category_create" class="btn btn-primary">Add Category</a>
  </div>
<?php
  // Build maps: parents and their children per type
  $byType = ['expense'=>[], 'income'=>[]];
  foreach ($rows as $c) { $byType[$c['type']][] = $c; }
  function groupCats($list){
    $parents=[]; $children=[];
    foreach ($list as $c) {
      if (empty($c['parent_id'])) $parents[$c['id']]=$c; else $children[$c['parent_id']][]=$c;
    }
    // ensure children arrays
    foreach ($parents as $pid=>&$p) { $p['children'] = $children[$pid] ?? []; }
    unset($p);
    return $parents;
  }
  $expTree = groupCats($byType['expense']);
  $incTree = groupCats($byType['income']);
?>
<div class="row g-3">
  <div class="col-md-6">
    <div class="card"><div class="card-body">
      <h6 class="mb-3">Expense Categories</h6>
      <ul class="list-group">
      <?php foreach ($expTree as $p): ?>
        <li class="list-group-item">
          <div class="d-flex justify-content-between align-items-center">
            <strong><?= e($p['name']) ?></strong>
            <span>
              <a class="btn btn-sm btn-outline-secondary" href="index.php?route=category_edit&id=<?= (int)$p['id'] ?>">Edit</a>
              <form method="post" action="index.php?route=category_delete&id=<?= (int)$p['id'] ?>" class="d-inline" onsubmit="return confirm('Delete category?');">
                <?= csrf_field() ?><button class="btn btn-sm btn-outline-danger">Delete</button>
              </form>
            </span>
          </div>
          <?php if (!empty($p['children'])): ?>
            <ul class="mt-2">
              <?php foreach ($p['children'] as $ch): ?>
                <li class="d-flex justify-content-between align-items-center">
                  <span><?= e($ch['name']) ?></span>
                  <span>
                    <a class="btn btn-sm btn-outline-secondary" href="index.php?route=category_edit&id=<?= (int)$ch['id'] ?>">Edit</a>
                    <form method="post" action="index.php?route=category_delete&id=<?= (int)$ch['id'] ?>" class="d-inline" onsubmit="return confirm('Delete category?');">
                      <?= csrf_field() ?><button class="btn btn-sm btn-outline-danger">Delete</button>
                    </form>
                  </span>
                </li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </li>
      <?php endforeach; ?>
      </ul>
    </div></div>
  </div>
  <div class="col-md-6">
    <div class="card"><div class="card-body">
      <h6 class="mb-3">Income Categories</h6>
      <ul class="list-group">
      <?php foreach ($incTree as $p): ?>
        <li class="list-group-item">
          <div class="d-flex justify-content-between align-items-center">
            <strong><?= e($p['name']) ?></strong>
            <span>
              <a class="btn btn-sm btn-outline-secondary" href="index.php?route=category_edit&id=<?= (int)$p['id'] ?>">Edit</a>
              <form method="post" action="index.php?route=category_delete&id=<?= (int)$p['id'] ?>" class="d-inline" onsubmit="return confirm('Delete category?');">
                <?= csrf_field() ?><button class="btn btn-sm btn-outline-danger">Delete</button>
              </form>
            </span>
          </div>
          <?php if (!empty($p['children'])): ?>
            <ul class="mt-2">
              <?php foreach ($p['children'] as $ch): ?>
                <li class="d-flex justify-content-between align-items-center">
                  <span><?= e($ch['name']) ?></span>
                  <span>
                    <a class="btn btn-sm btn-outline-secondary" href="index.php?route=category_edit&id=<?= (int)$ch['id'] ?>">Edit</a>
                    <form method="post" action="index.php?route=category_delete&id=<?= (int)$ch['id'] ?>" class="d-inline" onsubmit="return confirm('Delete category?');">
                      <?= csrf_field() ?><button class="btn btn-sm btn-outline-danger">Delete</button>
                    </form>
                  </span>
                </li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </li>
      <?php endforeach; ?>
      </ul>
    </div></div>
  </div>
</div>
<?php require __DIR__ . '/../layout/footer.php'; ?>
