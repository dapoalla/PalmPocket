<?php require __DIR__ . '/../layout/header.php'; ?>
<h3 class="mb-3">Backups</h3>
<?php if (!empty($ok)): ?><div class="alert alert-success">Import completed.</div><?php endif; ?>
<?php if (!empty($error)): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<div class="d-flex gap-2 mb-3">
  <form method="post" action="index.php?route=backup_create">
    <?= csrf_field() ?>
    <button class="btn btn-primary" type="submit">Create Backup</button>
  </form>
  <form method="post" action="index.php?route=backup_import" enctype="multipart/form-data" class="d-flex gap-2 align-items-center flex-wrap">
    <?= csrf_field() ?>
    <div>
      <div class="form-text">JSON Backup</div>
      <input type="file" name="backup" accept="application/json" class="form-control" required>
    </div>
    <div>
      <div class="form-text">Receipts ZIP (optional)</div>
      <input type="file" name="receipts_zip" accept="application/zip" class="form-control">
    </div>
    <button class="btn btn-outline-secondary" type="submit" onclick="return confirm('Importing will overwrite your existing data for this account. Proceed?')">Import Backup</button>
  </form>
</div>
<div class="card"><div class="card-body p-0">
  <div class="table-responsive">
    <table class="table table-striped mb-0">
      <thead><tr>
        <th>File</th><th>Date</th><th></th>
      </tr></thead>
      <tbody>
      <?php foreach ($rows as $b): ?>
        <tr>
          <td><?= e(basename($b['file_path'])) ?></td>
          <td><?= e($b['created_at']) ?></td>
          <td class="text-end">
            <a class="btn btn-sm btn-outline-primary" href="index.php?route=backup_download&id=<?= (int)$b['id'] ?>">Download</a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div></div>
<?php require __DIR__ . '/../layout/footer.php'; ?>
