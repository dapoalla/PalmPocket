<?php
namespace App\Controllers;

use App\Core\Auth;
use PDO;

class LoansController {
    private PDO $db; private Auth $auth;
    public function __construct(PDO $pdo, Auth $auth){ $this->db=$pdo; $this->auth=$auth; }

    public function index(): void {
        $uid = $this->auth->user()['id'];
        $given = $this->mine("SELECT e.* FROM expenses e WHERE e.user_id=? AND e.loan_given=1 AND e.loan_settled=0 ORDER BY e.date DESC, e.id DESC", [$uid]);
        $taken = $this->mine("SELECT i.* FROM incomes i WHERE i.user_id=? AND i.loan_taken=1 AND i.loan_settled=0 ORDER BY i.date DESC, i.id DESC", [$uid]);
        $wallets = $this->mine('SELECT id,name FROM wallets WHERE user_id=? ORDER BY name', [$uid]);
        require __DIR__ . '/../views/loans/index.php';
    }

    public function settleGiven(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $id = (int)($_GET['id'] ?? ($_POST['id'] ?? 0));
        $wallet_id = (int)($_POST['wallet_id'] ?? 0);
        $row = $this->one('SELECT * FROM expenses WHERE id=? AND user_id=? AND loan_given=1 AND loan_settled=0', [$id,$uid]);
        if (!$row) { http_response_code(404); exit('Loan not found'); }
        if ($wallet_id<=0) { http_response_code(400); exit('Wallet required'); }
        $catId = $this->ensureCategory($uid, 'Debts', 'income');
        $this->db->beginTransaction();
        try {
            // create income into selected wallet
            $stmt = $this->db->prepare('INSERT INTO incomes(user_id,wallet_id,category_id,source,loan_taken,loan_party,loan_due,loan_settled,amount,date,note) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
            $stmt->execute([$uid,$wallet_id,$catId,'Loan repayment',0,$row['loan_party'],$row['loan_due'],1,$row['amount'],date('Y-m-d'),'Auto from loan settlement']);
            // update wallet balance
            $this->db->prepare('UPDATE wallets SET balance=balance+? WHERE id=? AND user_id=?')->execute([$row['amount'],$wallet_id,$uid]);
            // mark original expense settled
            $this->db->prepare('UPDATE expenses SET loan_settled=1 WHERE id=? AND user_id=?')->execute([$id,$uid]);
            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollBack();
            http_response_code(500); exit($e->getMessage());
        }
        redirect('loans');
    }

    public function settleTaken(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $id = (int)($_GET['id'] ?? ($_POST['id'] ?? 0));
        $wallet_id = (int)($_POST['wallet_id'] ?? 0);
        $row = $this->one('SELECT * FROM incomes WHERE id=? AND user_id=? AND loan_taken=1 AND loan_settled=0', [$id,$uid]);
        if (!$row) { http_response_code(404); exit('Loan not found'); }
        if ($wallet_id<=0) { http_response_code(400); exit('Wallet required'); }
        $catId = $this->ensureCategory($uid, 'Debts', 'expense');
        $this->db->beginTransaction();
        try {
            // create expense from selected wallet
            $stmt = $this->db->prepare('INSERT INTO expenses(user_id,wallet_id,category_id,description,loan_given,loan_party,loan_due,loan_settled,amount,date,note) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
            $stmt->execute([$uid,$wallet_id,$catId,'Loan repayment',0,$row['loan_party'],$row['loan_due'],1,$row['amount'],date('Y-m-d'),'Auto from loan settlement']);
            // update wallet balance
            $this->db->prepare('UPDATE wallets SET balance=balance-? WHERE id=? AND user_id=?')->execute([$row['amount'],$wallet_id,$uid]);
            // mark original income settled
            $this->db->prepare('UPDATE incomes SET loan_settled=1 WHERE id=? AND user_id=?')->execute([$id,$uid]);
            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollBack();
            http_response_code(500); exit($e->getMessage());
        }
        redirect('loans');
    }

    private function ensureCategory(int $uid, string $name, string $type): int {
        $row = $this->one('SELECT id FROM categories WHERE user_id=? AND name=? AND type=?', [$uid,$name,$type]);
        if ($row) return (int)$row['id'];
        $this->db->prepare('INSERT INTO categories(user_id,name,type) VALUES (?,?,?)')->execute([$uid,$name,$type]);
        return (int)$this->db->lastInsertId();
    }

    private function mine(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetchAll(PDO::FETCH_ASSOC); }
    private function one(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetch(PDO::FETCH_ASSOC); }
}
