document.addEventListener('DOMContentLoaded', function(){
  var toggle = document.getElementById('sidebarToggle');
  var sidebar = document.getElementById('appSidebar');
  if (toggle && sidebar) {
    toggle.addEventListener('click', function(){
      if (window.getComputedStyle(sidebar).display === 'none') {
        sidebar.classList.remove('d-none');
      } else {
        sidebar.classList.add('d-none');
      }
    });
    // Hide sidebar when clicking outside on mobile
    document.addEventListener('click', function(e){
      if (window.innerWidth < 768) {
        if (!sidebar.contains(e.target) && e.target !== toggle) {
          sidebar.classList.add('d-none');
        }
      }
    });
  }
});
