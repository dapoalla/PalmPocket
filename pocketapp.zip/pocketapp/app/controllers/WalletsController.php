<?php
namespace App\Controllers;

use App\Core\Auth;
use PDO;

class WalletsController {
    private PDO $db; private Auth $auth;
    public function __construct(PDO $pdo, Auth $auth){ $this->db=$pdo; $this->auth=$auth; }

    public function index(): void {
        $uid = $this->auth->user()['id'];
        $wallets = $this->mine('SELECT * FROM wallets WHERE user_id=? ORDER BY name', [$uid]);
        $transfers = $this->mine('SELECT t.*, fw.name AS from_wallet, tw.name AS to_wallet FROM transfers t INNER JOIN wallets fw ON fw.id=t.from_wallet_id INNER JOIN wallets tw ON tw.id=t.to_wallet_id WHERE t.user_id=? ORDER BY t.date DESC, t.id DESC LIMIT 100', [$uid]);
        require __DIR__ . '/../views/wallets/index.php';
    }

    public function create(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            $type = $_POST['type'] ?? 'custom';
            $balance = (float)($_POST['balance'] ?? 0);
            if ($name === '' || !in_array($type, ['cash','bank','mobile','custom'], true)) {
                $error = 'Invalid input';
            } else {
                $stmt = $this->db->prepare('INSERT INTO wallets(user_id,name,type,balance) VALUES (?,?,?,?)');
                $stmt->execute([$uid, $name, $type, $balance]);
                redirect('wallets');
            }
        }
        require __DIR__ . '/../views/wallets/create.php';
    }

    public function edit(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $id = (int)($_GET['id'] ?? 0);
        $wal = $this->one('SELECT * FROM wallets WHERE id=? AND user_id=?', [$id, $uid]);
        if (!$wal) { http_response_code(404); exit('Not found'); }
        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            $type = $_POST['type'] ?? 'custom';
            $balance = (float)($_POST['balance'] ?? 0);
            if ($name === '' || !in_array($type, ['cash','bank','mobile','custom'], true)) {
                $error = 'Invalid input';
            } else {
                $stmt = $this->db->prepare('UPDATE wallets SET name=?, type=?, balance=? WHERE id=? AND user_id=?');
                $stmt->execute([$name, $type, $balance, $id, $uid]);
                redirect('wallets');
            }
        }
        require __DIR__ . '/../views/wallets/edit.php';
    }

    public function delete(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $id = (int)($_GET['id'] ?? 0);
        // Prevent delete if referenced?
        $this->db->prepare('DELETE FROM wallets WHERE id=? AND user_id=?')->execute([$id, $uid]);
        redirect('wallets');
    }

    public function transfer(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $from_id = (int)($_POST['from_wallet_id'] ?? 0);
            $to_id = (int)($_POST['to_wallet_id'] ?? 0);
            $amount = max(0, (float)($_POST['amount'] ?? 0));
            $date = $_POST['date'] ?? date('Y-m-d');
            $note = trim($_POST['note'] ?? '');
            if ($from_id === $to_id || $amount <= 0) {
                $error = 'Invalid transfer details';
            } else {
                $this->db->beginTransaction();
                try {
                    // Verify ownership
                    $own = $this->one('SELECT COUNT(*) as c FROM wallets WHERE user_id=? AND id IN (?,?)', [$uid, $from_id, $to_id]);
                    if ((int)$own['c'] !== 2) throw new \Exception('Wallets not found');
                    $this->db->prepare('INSERT INTO transfers(user_id, from_wallet_id, to_wallet_id, amount, date, note) VALUES (?,?,?,?,?,?)')
                        ->execute([$uid, $from_id, $to_id, $amount, $date, $note]);
                    $this->db->prepare('UPDATE wallets SET balance=balance-? WHERE id=? AND user_id=?')->execute([$amount, $from_id, $uid]);
                    $this->db->prepare('UPDATE wallets SET balance=balance+? WHERE id=? AND user_id=?')->execute([$amount, $to_id, $uid]);
                    $this->db->commit();
                    redirect('wallets');
                } catch (\Throwable $e) {
                    $this->db->rollBack();
                    $error = $e->getMessage();
                }
            }
        }
        $wallets = $this->mine('SELECT id,name FROM wallets WHERE user_id=? ORDER BY name', [$uid]);
        require __DIR__ . '/../views/wallets/transfer.php';
    }

    private function mine(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetchAll(PDO::FETCH_ASSOC); }
    private function one(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetch(PDO::FETCH_ASSOC); }
}
