<?php require __DIR__ . '/../layout/header.php'; ?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h3>Income</h3>
  <a href="index.php?route=income_create" class="btn btn-primary">Add Income</a>
</div>
<div class="card"><div class="card-body p-0">
  <div class="table-responsive">
    <table class="table table-striped mb-0">
      <thead><tr>
        <th>Date</th><th>Category</th><th>Wallet</th><th>Amount</th><th>Source</th><th>Note</th><th></th>
      </tr></thead>
      <tbody>
      <?php foreach ($incomes as $x): ?>
        <tr>
          <td><?= e($x['date']) ?></td>
          <td><?= e($x['category'] ?? '-') ?></td>
          <td><?= e($x['wallet']) ?></td>
          <td>₦<?= number_format((float)$x['amount'], 2) ?></td>
          <td><?= e($x['source'] ?? '') ?></td>
          <td><?= e($x['note'] ?? '') ?></td>
          <td class="text-end">
            <a class="btn btn-sm btn-outline-secondary" href="index.php?route=income_edit&id=<?= (int)$x['id'] ?>">Edit</a>
            <form method="post" action="index.php?route=income_delete&id=<?= (int)$x['id'] ?>" class="d-inline" onsubmit="return confirm('Delete income?');">
              <?= csrf_field() ?>
              <button class="btn btn-sm btn-outline-danger">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div></div>
<?php require __DIR__ . '/../layout/footer.php'; ?>
