<?php require __DIR__ . '/../layout/header.php'; ?>
<div class="container" style="max-width:480px;">
  <h3 class="mb-3">Login</h3>
  <?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= e($error) ?></div>
  <?php endif; ?>
  <form method="post">
    <?= csrf_field() ?>
    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="email" name="email" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Password</label>
      <input type="password" name="password" class="form-control" required>
    </div>
    <div class="d-flex justify-content-between align-items-center">
      <button class="btn btn-primary" type="submit">Login</button>
      <a href="index.php?route=forgot">Forgot password?</a>
    </div>
  </form>
</div>
<?php require __DIR__ . '/../layout/footer.php'; ?>
