<?php require __DIR__ . '/../layout/header.php'; ?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h3 class="m-0">Reports</h3>
  <form class="d-flex gap-2 align-items-end" method="get" action="index.php">
    <input type="hidden" name="route" value="reports">
    <div>
      <label class="form-label">From</label>
      <input class="form-control" type="date" name="date_from" value="<?= e($_GET['date_from'] ?? date('Y-m-01')) ?>">
    </div>
    <div>
      <label class="form-label">To</label>
      <input class="form-control" type="date" name="date_to" value="<?= e($_GET['date_to'] ?? date('Y-m-t')) ?>">
    </div>
    <div>
      <label class="form-label">Type</label>
      <?php $t = $_GET['t'] ?? 'all'; ?>
      <select class="form-select" name="t">
        <option value="all" <?= $t==='all'?'selected':'' ?>>All</option>
        <option value="expenses" <?= $t==='expenses'?'selected':'' ?>>Expenses</option>
        <option value="incomes" <?= $t==='incomes'?'selected':'' ?>>Incomes</option>
      </select>
    </div>
    <div>
      <button class="btn btn-primary" type="submit">Apply</button>
    </div>
  </form>
  </div>
<div class="row g-3 mb-4">
  <div class="col-md-6">
    <div class="card"><div class="card-body">
      <div class="d-flex justify-content-between align-items-center">
        <h6 class="m-0">Category Spending (Pie)</h6>
        <div>
          <?php $df = urlencode($_GET['date_from'] ?? ''); $dt = urlencode($_GET['date_to'] ?? ''); ?>
          <a class="btn btn-sm btn-outline-secondary" href="index.php?route=report_csv&type=incomes&date_from=<?= $df ?>&date_to=<?= $dt ?>">Export Incomes CSV</a>
          <a class="btn btn-sm btn-outline-secondary" href="index.php?route=report_csv&type=expenses&date_from=<?= $df ?>&date_to=<?= $dt ?>">Export Expenses CSV</a>
        </div>
      </div>
      <canvas id="r_category" height="140"></canvas>
    </div></div>
  </div>
  <div class="col-md-6">
    <div class="card h-100"><div class="card-body">
      <h6 class="mb-2">Transactions</h6>
      <div class="table-responsive" style="max-height:360px;">
        <table class="table table-sm table-striped">
          <thead><tr>
            <th>Date</th><th>Type</th><th>Wallet</th><th>Category</th><th>Label</th><th class="text-end">Amount</th><th>Note</th>
          </tr></thead>
          <tbody>
          <?php foreach (($txRows ?? []) as $r): ?>
            <tr>
              <td><?= e($r['date']) ?></td>
              <td><?= e($r['kind']) ?></td>
              <td><?= e($r['wallet'] ?? '-') ?></td>
              <td><?= e($r['category'] ?? '-') ?></td>
              <td><?= e($r['label'] ?? '') ?></td>
              <td class="text-end">₦<?= number_format((float)$r['amount'], 2) ?></td>
              <td><?= e($r['note'] ?? '') ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div></div>
  </div>
</div>
<script>
const catLabels = <?= json_encode(array_column($catRows,'name')) ?>;
const catData = <?= json_encode(array_map('floatval', array_column($catRows,'total'))) ?>;
new Chart(document.getElementById('r_category'), {type:'pie', data:{labels:catLabels, datasets:[{data:catData}]}});
</script>
<?php require __DIR__ . '/../layout/footer.php'; ?>
