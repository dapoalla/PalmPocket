<?php
// Installer Step 1: Collect DB credentials and admin user details
if (file_exists(__DIR__ . '/../config.php')) {
    echo '<p>Application already installed.</p>';
    exit;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Install - Personal Finance Manager</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5" style="max-width:820px;">
  <h2 class="mb-4">Personal Finance Manager - Installer</h2>
  <form method="post" action="install.php">
    <div class="row g-3">
      <div class="col-12"><h5>Database Configuration</h5></div>
      <div class="col-md-6">
        <label class="form-label">DB Host</label>
        <input class="form-control" name="db_host" value="localhost" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">DB Name</label>
        <input class="form-control" name="db_name" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">DB User</label>
        <input class="form-control" name="db_user" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">DB Password</label>
        <input class="form-control" name="db_pass" type="password">
      </div>
      <div class="col-12"><h5 class="mt-4">Admin User</h5></div>
      <div class="col-md-6">
        <label class="form-label">Admin Name</label>
        <input class="form-control" name="admin_name" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">Admin Email</label>
        <input class="form-control" name="admin_email" type="email" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">Admin Password</label>
        <input class="form-control" name="admin_password" type="password" required>
      </div>
    </div>
    <div class="mt-4">
      <div class="form-check mb-3">
        <input class="form-check-input" type="checkbox" value="1" id="overwrite" name="overwrite">
        <label class="form-check-label" for="overwrite">
          Overwrite existing tables (DROPs and recreates schema)
        </label>
      </div>
    </div>
    <div class="mt-2 d-flex gap-2">
      <button class="btn btn-primary" type="submit">Install</button>
    </div>
  </form>
</div>
</body>
</html>
