<?php require __DIR__ . '/../layout/header.php'; ?>
<h3 class="mb-3">Edit Income</h3>
<?php if (!empty($error)): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<form method="post">
  <?= csrf_field() ?>
  <div class="row g-3">
    <div class="col-md-3">
      <label class="form-label">Amount</label>
      <input class="form-control" type="number" step="0.01" name="amount" value="<?= e((string)$inc['amount']) ?>" required>
    </div>
    <div class="col-md-3">
      <label class="form-label">Wallet</label>
      <select class="form-select" name="wallet_id" required>
        <?php foreach ($wallets as $w): $sel = $w['id']==$inc['wallet_id'] ? 'selected' : ''; ?>
          <option value="<?= (int)$w['id'] ?>" <?= $sel ?>><?= e($w['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3">
      <label class="form-label">Category</label>
      <select class="form-select" name="category_id">
        <option value="">- none -</option>
        <?php foreach ($cats as $c): $sel = $c['id']==$inc['category_id'] ? 'selected' : ''; ?>
          <option value="<?= (int)$c['id'] ?>" <?= $sel ?>><?= e($c['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3">
      <label class="form-label">Date</label>
      <input class="form-control" type="date" name="date" value="<?= e($inc['date']) ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Source</label>
      <input class="form-control" name="source" value="<?= e($inc['source']) ?>">
    </div>
    <div class="col-md-6">
      <label class="form-label">Note</label>
      <input class="form-control" name="note" value="<?= e($inc['note']) ?>">
    </div>
  </div>
  <div class="mt-3 d-flex gap-2">
    <button class="btn btn-primary" type="submit">Update</button>
    <a class="btn btn-secondary" href="index.php?route=incomes">Cancel</a>
  </div>
</form>
<?php require __DIR__ . '/../layout/footer.php'; ?>
