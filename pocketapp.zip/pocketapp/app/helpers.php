<?php
function view(string $path, array $data = []): void {
    extract($data, EXTR_SKIP);
    require __DIR__ . "/views/layout/header.php";
    require __DIR__ . "/views/" . $path . ".php";
    require __DIR__ . "/views/layout/footer.php";
}

function redirect(string $route): void {
    $url = 'index.php?route=' . urlencode($route);
    header('Location: ' . $url);
    exit;
}

function e(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}

function verify_csrf(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf'] ?? '';
        if (!$token || !hash_equals($_SESSION['csrf'] ?? '', $token)) {
            http_response_code(419);
            exit('Invalid CSRF token');
        }
    }
}
