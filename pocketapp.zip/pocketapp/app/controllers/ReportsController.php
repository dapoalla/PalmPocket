<?php
namespace App\Controllers;

use App\Core\Auth;
use PDO;

class ReportsController {
    private PDO $db; private Auth $auth;
    public function __construct(PDO $pdo, Auth $auth){ $this->db=$pdo; $this->auth=$auth; }

    public function index(): void {
        $uid = $this->auth->user()['id'];
        $date_from = $_GET['date_from'] ?? date('Y-m-01');
        $date_to = $_GET['date_to'] ?? date('Y-m-t');
        // Transactions list by filter
        $t = $_GET['t'] ?? 'all'; // all|expenses|incomes
        if ($t === 'expenses') {
            $txStmt = $this->db->prepare("SELECT 'expense' kind, e.id, e.date, w.name wallet, c.name category, e.description label, e.amount, e.note FROM expenses e LEFT JOIN wallets w ON w.id=e.wallet_id LEFT JOIN categories c ON c.id=e.category_id WHERE e.user_id=? AND e.date BETWEEN ? AND ? ORDER BY e.date DESC, e.id DESC");
            $txStmt->execute([$uid,$date_from,$date_to]);
        } elseif ($t === 'incomes') {
            $txStmt = $this->db->prepare("SELECT 'income' kind, i.id, i.date, w.name wallet, c.name category, i.source label, i.amount, i.note FROM incomes i LEFT JOIN wallets w ON w.id=i.wallet_id LEFT JOIN categories c ON c.id=i.category_id WHERE i.user_id=? AND i.date BETWEEN ? AND ? ORDER BY i.date DESC, i.id DESC");
            $txStmt->execute([$uid,$date_from,$date_to]);
        } else {
            $txStmt = $this->db->prepare("SELECT * FROM (
                SELECT 'expense' kind, e.id, e.date, w.name wallet, c.name category, e.description label, e.amount, e.note FROM expenses e LEFT JOIN wallets w ON w.id=e.wallet_id LEFT JOIN categories c ON c.id=e.category_id WHERE e.user_id=? AND e.date BETWEEN ? AND ?
                UNION ALL
                SELECT 'income' kind, i.id, i.date, w.name wallet, c.name category, i.source label, i.amount, i.note FROM incomes i LEFT JOIN wallets w ON w.id=i.wallet_id LEFT JOIN categories c ON c.id=i.category_id WHERE i.user_id=? AND i.date BETWEEN ? AND ?
            ) x ORDER BY date DESC, id DESC");
            $txStmt->execute([$uid,$date_from,$date_to,$uid,$date_from,$date_to]);
        }
        $txRows = $txStmt->fetchAll(PDO::FETCH_ASSOC);

        // Category spending breakdown in range (by main parent category)
        $cat = $this->db->prepare("SELECT cp.name, COALESCE(SUM(e.amount),0) total
                                    FROM expenses e
                                    LEFT JOIN categories c ON c.id=e.category_id AND c.user_id=e.user_id
                                    LEFT JOIN categories cp ON cp.id = COALESCE(c.parent_id, c.id)
                                    WHERE e.user_id=? AND e.date BETWEEN ? AND ? AND cp.type='expense'
                                    GROUP BY cp.id, cp.name
                                    ORDER BY total DESC");
        $cat->execute([$uid,$date_from,$date_to]);
        $catRows = $cat->fetchAll(PDO::FETCH_ASSOC);

        // Budgets analytics over period: include budgets that overlap the selected range
        $bStmt = $this->db->prepare("SELECT b.*, c.name AS category
                                     FROM budgets b INNER JOIN categories c ON c.id=b.category_id
                                     WHERE b.user_id=? AND NOT (b.end_date < ? OR b.start_date > ?)
                                     ORDER BY b.start_date DESC, b.id DESC");
        $bStmt->execute([$uid, $date_from, $date_to]);
        $budgetRows = $bStmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($budgetRows as &$b) {
            // overlap window between budget period and selected period
            $from = max($b['start_date'], $date_from);
            $to = min($b['end_date'], $date_to);
            $spent = $this->scalar("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE user_id=? AND category_id=? AND date BETWEEN ? AND ?",
                                   [$uid, $b['category_id'], $from, $to]);
            $b['spent'] = (float)$spent;
            $b['percent'] = $b['amount'] > 0 ? min(999, round(($b['spent'] / (float)$b['amount']) * 100)) : 0;
            $b['from'] = $from; $b['to'] = $to;
            $b['exceeded'] = $b['spent'] > (float)$b['amount'];
        }
        unset($b);
        require __DIR__ . '/../views/reports/index.php';
    }

    public function csv(): void {
        $uid = $this->auth->user()['id'];
        $type = $_GET['type'] ?? 'expenses'; // 'expenses' or 'incomes'
        $date_from = $_GET['date_from'] ?? null;
        $date_to = $_GET['date_to'] ?? null;
        $filename = $type . '_' . date('Ymd_His') . '.csv';
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename=' . $filename);
        $out = fopen('php://output', 'w');
        if ($type === 'incomes') {
            fputcsv($out, ['date','wallet','category','source','amount','note']);
            if ($date_from && $date_to) {
                $stmt = $this->db->prepare("SELECT i.date, w.name wallet, c.name category, i.source, i.amount, i.note FROM incomes i LEFT JOIN wallets w ON w.id=i.wallet_id LEFT JOIN categories c ON c.id=i.category_id WHERE i.user_id=? AND i.date BETWEEN ? AND ? ORDER BY i.date DESC, i.id DESC");
                $stmt->execute([$uid,$date_from,$date_to]);
            } else {
                $stmt = $this->db->prepare("SELECT i.date, w.name wallet, c.name category, i.source, i.amount, i.note FROM incomes i LEFT JOIN wallets w ON w.id=i.wallet_id LEFT JOIN categories c ON c.id=i.category_id WHERE i.user_id=? ORDER BY i.date DESC, i.id DESC");
                $stmt->execute([$uid]);
            }
            while ($r = $stmt->fetch(PDO::FETCH_NUM)) fputcsv($out, $r);
        } else {
            fputcsv($out, ['date','wallet','category','description','amount','note','receipt']);
            if ($date_from && $date_to) {
                $stmt = $this->db->prepare("SELECT e.date, w.name wallet, c.name category, e.description, e.amount, e.note, e.receipt_path FROM expenses e LEFT JOIN wallets w ON w.id=e.wallet_id LEFT JOIN categories c ON c.id=e.category_id WHERE e.user_id=? AND e.date BETWEEN ? AND ? ORDER BY e.date DESC, e.id DESC");
                $stmt->execute([$uid,$date_from,$date_to]);
            } else {
                $stmt = $this->db->prepare("SELECT e.date, w.name wallet, c.name category, e.description, e.amount, e.note, e.receipt_path FROM expenses e LEFT JOIN wallets w ON w.id=e.wallet_id LEFT JOIN categories c ON c.id=e.category_id WHERE e.user_id=? ORDER BY e.date DESC, e.id DESC");
                $stmt->execute([$uid]);
            }
            while ($r = $stmt->fetch(PDO::FETCH_NUM)) fputcsv($out, $r);
        }
        fclose($out);
        exit;
    }

    private function scalar(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetchColumn(); }
}
