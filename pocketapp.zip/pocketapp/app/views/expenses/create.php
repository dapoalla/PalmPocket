<?php require __DIR__ . '/../layout/header.php'; ?>
<h3 class="mb-3">Add Expense</h3>
<?php if (!empty($error)): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<form method="post" enctype="multipart/form-data">
  <?= csrf_field() ?>
  <div class="row g-3">
    <div class="col-12">
      <label class="form-label">Description</label>
      <input class="form-control" name="description" required>
    </div>
    <div class="col-12">
      <div class="form-check">
        <input class="form-check-input" type="checkbox" name="loan_given" id="loan_given">
        <label class="form-check-label" for="loan_given">This expense is a loan I gave to someone</label>
      </div>
    </div>
    <div class="col-md-6">
      <label class="form-label">Debtor Name</label>
      <input class="form-control" name="loan_party" placeholder="Who owes you?">
    </div>
    <div class="col-md-6">
      <label class="form-label">Due Date</label>
      <input class="form-control" type="date" name="loan_due">
    </div>
    <div class="col-md-3">
      <label class="form-label">Amount</label>
      <input class="form-control" type="number" step="0.01" name="amount" required>
    </div>
    <div class="col-md-3">
      <label class="form-label">Wallet</label>
      <select class="form-select" name="wallet_id" required>
        <?php foreach ($wallets as $w): ?><option value="<?= (int)$w['id'] ?>"><?= e($w['name']) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3">
      <label class="form-label">Category</label>
      <select class="form-select" name="category_id">
        <option value="">- none -</option>
        <?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3">
      <label class="form-label">Date</label>
      <input class="form-control" type="date" name="date" value="<?= date('Y-m-d') ?>" required>
    </div>
    <div class="col-12">
      <label class="form-label">Note</label>
      <input class="form-control" name="note">
    </div>
    <div class="col-md-6">
      <label class="form-label">Receipt (jpg/png/gif/pdf/webp)</label>
      <input class="form-control" type="file" name="receipt" accept="image/*,application/pdf">
    </div>
    <div class="col-md-3 form-check mt-4">
      <input class="form-check-input" type="checkbox" name="repeat" id="repeat">
      <label class="form-check-label" for="repeat">Repeat</label>
    </div>
  </div>
  <div class="mt-3 d-flex gap-2">
    <button class="btn btn-primary" type="submit">Save</button>
    <a class="btn btn-secondary" href="index.php?route=expenses">Cancel</a>
  </div>
</form>
<?php require __DIR__ . '/../layout/footer.php'; ?>
