<?php
namespace App\Models;

use PDO;

class User {
    private PDO $db; public function __construct(PDO $pdo){ $this->db=$pdo; }
}
