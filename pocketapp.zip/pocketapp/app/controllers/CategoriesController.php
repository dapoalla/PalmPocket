<?php
namespace App\Controllers;

use App\Core\Auth;
use PDO;

class CategoriesController {
    private PDO $db; private Auth $auth;
    public function __construct(PDO $pdo, Auth $auth){ $this->db=$pdo; $this->auth=$auth; }

    public function index(): void {
        $uid = $this->auth->user()['id'];
        $rows = $this->mine('SELECT * FROM categories WHERE user_id=? ORDER BY type, parent_id IS NOT NULL, name', [$uid]);
        require __DIR__ . '/../views/categories/index.php';
    }

    public function create(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            $type = $_POST['type'] ?? 'expense';
            $parent_id = isset($_POST['parent_id']) && $_POST['parent_id']!=='' ? (int)$_POST['parent_id'] : null;
            if ($name === '' || !in_array($type, ['income','expense'], true)) {
                $error = 'Invalid input';
            } else {
                if ($parent_id) {
                    // Ensure parent belongs to user and same type
                    $p = $this->one('SELECT id FROM categories WHERE id=? AND user_id=? AND type=?', [$parent_id, $uid, $type]);
                    if (!$p) $parent_id = null;
                }
                $stmt = $this->db->prepare('INSERT INTO categories(user_id,name,type,parent_id) VALUES (?,?,?,?)');
                $stmt->execute([$uid, $name, $type, $parent_id]);
                redirect('categories');
            }
        }
        $parents = $this->mine('SELECT id,name,type FROM categories WHERE user_id=? AND parent_id IS NULL ORDER BY type,name', [$uid]);
        require __DIR__ . '/../views/categories/create.php';
    }

    public function edit(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $id = (int)($_GET['id'] ?? 0);
        $cat = $this->one('SELECT * FROM categories WHERE id=? AND user_id=?', [$id, $uid]);
        if (!$cat) { http_response_code(404); exit('Not found'); }
        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            $type = $_POST['type'] ?? 'expense';
            $parent_id = isset($_POST['parent_id']) && $_POST['parent_id']!=='' ? (int)$_POST['parent_id'] : null;
            if ($name === '' || !in_array($type, ['income','expense'], true)) {
                $error = 'Invalid input';
            } else {
                if ($parent_id === $id) $parent_id = null; // prevent self-parenting
                if ($parent_id) {
                    $p = $this->one('SELECT id FROM categories WHERE id=? AND user_id=? AND type=?', [$parent_id, $uid, $type]);
                    if (!$p) $parent_id = null;
                }
                $stmt = $this->db->prepare('UPDATE categories SET name=?, type=?, parent_id=? WHERE id=? AND user_id=?');
                $stmt->execute([$name, $type, $parent_id, $id, $uid]);
                redirect('categories');
            }
        }
        $parents = $this->mine('SELECT id,name,type FROM categories WHERE user_id=? AND parent_id IS NULL ORDER BY type,name', [$uid]);
        require __DIR__ . '/../views/categories/edit.php';
    }

    public function delete(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $id = (int)($_GET['id'] ?? 0);
        $this->db->prepare('DELETE FROM categories WHERE id=? AND user_id=?')->execute([$id, $uid]);
        redirect('categories');
    }

    private function mine(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetchAll(PDO::FETCH_ASSOC); }
    private function one(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetch(PDO::FETCH_ASSOC); }
}
