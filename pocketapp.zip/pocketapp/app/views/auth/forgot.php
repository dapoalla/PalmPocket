<?php require __DIR__ . '/../layout/header.php'; ?>
<div class="container" style="max-width:480px;">
  <h3 class="mb-3">Forgot Password</h3>
  <?php if ($sent): ?>
    <div class="alert alert-success">If the email exists, a reset link has been generated.</div>
  <?php endif; ?>
  <form method="post">
    <?= csrf_field() ?>
    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="email" name="email" class="form-control" required>
    </div>
    <button class="btn btn-primary" type="submit">Send reset link</button>
  </form>
</div>
<?php require __DIR__ . '/../layout/footer.php'; ?>
