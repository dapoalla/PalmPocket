<?php require __DIR__ . '/../layout/header.php'; ?>
<h3 class="mb-3">Loans</h3>
<div class="row g-3">
  <div class="col-lg-6">
    <div class="card h-100"><div class="card-body">
      <div class="d-flex justify-content-between align-items-center mb-2">
        <h6 class="m-0">Loans Given (Debtors)</h6>
        <span class="badge bg-secondary">Outstanding: ₦<?= number_format(array_sum(array_map(fn($r)=> (float)$r['amount'], $given)),2) ?></span>
      </div>
      <div class="table-responsive">
        <table class="table table-sm align-middle">
          <thead><tr>
            <th>Date</th><th>Debtor</th><th>Description</th><th class="text-end">Amount</th><th>Due</th><th class="text-end">Settle</th>
          </tr></thead>
          <tbody>
          <?php foreach ($given as $r): ?>
            <tr>
              <td><?= e($r['date']) ?></td>
              <td><?= e($r['loan_party'] ?? '-') ?></td>
              <td><?= e($r['description']) ?></td>
              <td class="text-end">₦<?= number_format((float)$r['amount'],2) ?></td>
              <td><?= e($r['loan_due'] ?? '-') ?></td>
              <td class="text-end">
                <form method="post" action="index.php?route=loan_settle_given&id=<?= (int)$r['id'] ?>" class="d-flex gap-2 justify-content-end">
                  <?= csrf_field() ?>
                  <select class="form-select form-select-sm" name="wallet_id" style="max-width:160px" required>
                    <?php foreach ($wallets as $w): ?><option value="<?= (int)$w['id'] ?>"><?= e($w['name']) ?></option><?php endforeach; ?>
                  </select>
                  <button class="btn btn-sm btn-success" title="Mark as repaid">Settle</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div></div>
  </div>
  <div class="col-lg-6">
    <div class="card h-100"><div class="card-body">
      <div class="d-flex justify-content-between align-items-center mb-2">
        <h6 class="m-0">Loans Taken</h6>
        <span class="badge bg-secondary">Outstanding: ₦<?= number_format(array_sum(array_map(fn($r)=> (float)$r['amount'], $taken)),2) ?></span>
      </div>
      <div class="table-responsive">
        <table class="table table-sm align-middle">
          <thead><tr>
            <th>Date</th><th>Lender</th><th>Source</th><th class="text-end">Amount</th><th>Due</th><th class="text-end">Settle</th>
          </tr></thead>
          <tbody>
          <?php foreach ($taken as $r): ?>
            <tr>
              <td><?= e($r['date']) ?></td>
              <td><?= e($r['loan_party'] ?? '-') ?></td>
              <td><?= e($r['source']) ?></td>
              <td class="text-end">₦<?= number_format((float)$r['amount'],2) ?></td>
              <td><?= e($r['loan_due'] ?? '-') ?></td>
              <td class="text-end">
                <form method="post" action="index.php?route=loan_settle_taken&id=<?= (int)$r['id'] ?>" class="d-flex gap-2 justify-content-end">
                  <?= csrf_field() ?>
                  <select class="form-select form-select-sm" name="wallet_id" style="max-width:160px" required>
                    <?php foreach ($wallets as $w): ?><option value="<?= (int)$w['id'] ?>"><?= e($w['name']) ?></option><?php endforeach; ?>
                  </select>
                  <button class="btn btn-sm btn-danger" title="Repay">Repay</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div></div>
  </div>
</div>
<?php require __DIR__ . '/../layout/footer.php'; ?>
