<?php require __DIR__ . '/../layout/header.php'; ?>
<h3 class="mb-3">Edit Category</h3>
<?php if (!empty($error)): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<form method="post">
  <?= csrf_field() ?>
  <div class="row g-3">
    <div class="col-md-6">
      <label class="form-label">Name</label>
      <input class="form-control" name="name" value="<?= e($cat['name']) ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Type</label>
      <select class="form-select" name="type" id="cat_type" required>
        <option value="expense" <?= $cat['type']==='expense'?'selected':'' ?>>Expense</option>
        <option value="income" <?= $cat['type']==='income'?'selected':'' ?>>Income</option>
      </select>
    </div>
    <div class="col-md-6">
      <label class="form-label">Parent Category (optional)</label>
      <select class="form-select" name="parent_id" id="parent_id">
        <option value="">None (make this a main category)</option>
        <?php foreach (($parents ?? []) as $p): if ($p['id']==$cat['id']) continue; ?>
          <?php $sel = ($cat['parent_id']??null)==$p['id'] ? 'selected' : ''; ?>
          <option value="<?= (int)$p['id'] ?>" data-type="<?= e($p['type']) ?>" <?= $sel ?>><?= e($p['name']) ?> (<?= e($p['type']) ?>)</option>
        <?php endforeach; ?>
      </select>
      <div class="form-text">Choose a main category to nest under it.</div>
    </div>
  </div>
  <div class="mt-3 d-flex gap-2">
    <button class="btn btn-primary" type="submit">Update</button>
    <a class="btn btn-secondary" href="index.php?route=categories">Cancel</a>
  </div>
</form>
<script>
  (function(){
    var t=document.getElementById('cat_type'); var p=document.getElementById('parent_id');
    function filter(){
      var val=t.value; var opts=p.querySelectorAll('option[data-type]');
      opts.forEach(function(o){ o.hidden = (o.getAttribute('data-type')!==val); });
    }
    t.addEventListener('change', filter); filter();
  })();
</script>
<?php require __DIR__ . '/../layout/footer.php'; ?>
