<?php
// Sample config. The installer will generate config.php with these values filled.

define('APP_NAME', 'PalmPocket');
define('APP_VERSION', '1.0.0');

define('BASE_URL', rtrim((isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? ''), '/') . '/');

define('APP_ENV', 'production');

define('UPLOAD_DIR', __DIR__ . '/uploads');

define('RECEIPTS_DIR', __DIR__ . '/uploads/receipts');

define('BACKUPS_DIR', __DIR__ . '/backups');

// Database connection (filled by installer)
$DB_HOST = 'localhost';
$DB_NAME = 'pfm';
$DB_USER = 'root';
$DB_PASS = '';
$DB_CHARSET = 'utf8mb4';

$dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset={$DB_CHARSET}";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

$pdo = new PDO($dsn, $DB_USER, $DB_PASS, $options);
