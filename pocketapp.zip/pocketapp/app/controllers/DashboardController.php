<?php
namespace App\Controllers;

use App\Core\Auth;
use PDO;

class DashboardController {
    private PDO $db; private Auth $auth;
    public function __construct(PDO $pdo, Auth $auth){ $this->db=$pdo; $this->auth=$auth; }

    public function index(): void {
        $user = $this->auth->user();
        $uid = $user['id'];
        // Totals for current month
        $summary = [
            'income' => (float)$this->scalar('SELECT COALESCE(SUM(amount),0) FROM incomes WHERE user_id=? AND MONTH(date)=MONTH(CURDATE()) AND YEAR(date)=YEAR(CURDATE())', [$uid]),
            'expense' => (float)$this->scalar('SELECT COALESCE(SUM(amount),0) FROM expenses WHERE user_id=? AND MONTH(date)=MONTH(CURDATE()) AND YEAR(date)=YEAR(CURDATE())', [$uid]),
            'wallets' => (float)$this->scalar('SELECT COALESCE(SUM(balance),0) FROM wallets WHERE user_id=?', [$uid]),
        ];
        $wishlistTotal = (float)$this->scalar("SELECT COALESCE(SUM(wishlist_price),0) FROM goals WHERE user_id=? AND type='wishlist'", [$uid]);
        $savingTarget = (float)$this->scalar("SELECT COALESCE(SUM(target_amount),0) FROM goals WHERE user_id=? AND type='saving'", [$uid]);
        $savingSaved = (float)$this->scalar("SELECT COALESCE(SUM(saved_amount),0) FROM goals WHERE user_id=? AND type='saving'", [$uid]);
        // Outstanding loans
        $loansGivenOutstanding = (float)$this->scalar("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE user_id=? AND loan_given=1 AND loan_settled=0", [$uid]);
        $loansTakenOutstanding = (float)$this->scalar("SELECT COALESCE(SUM(amount),0) FROM incomes WHERE user_id=? AND loan_taken=1 AND loan_settled=0", [$uid]);
        // Top 5 categories (current month)
        $topExpenses = $this->list(
            "SELECT cp.name, COALESCE(SUM(e.amount),0) total
             FROM expenses e
             LEFT JOIN categories c ON c.id=e.category_id
             LEFT JOIN categories cp ON cp.id = COALESCE(c.parent_id, c.id)
             WHERE e.user_id=? AND MONTH(e.date)=MONTH(CURDATE()) AND YEAR(e.date)=YEAR(CURDATE())
             GROUP BY cp.id, cp.name
             ORDER BY total DESC",
            [$uid]
        );
        $topIncomes = $this->list(
            "SELECT c.name, COALESCE(SUM(i.amount),0) total
             FROM incomes i LEFT JOIN categories c ON c.id=i.category_id
             WHERE i.user_id=? AND MONTH(i.date)=MONTH(CURDATE()) AND YEAR(i.date)=YEAR(CURDATE())
             GROUP BY c.id, c.name
             ORDER BY total DESC
             LIMIT 5",
            [$uid]
        );
        view('dashboard/index', [
            'summary' => $summary,
            'user' => $user,
            'wishlistTotal' => $wishlistTotal,
            'savingTarget' => $savingTarget,
            'savingSaved' => $savingSaved,
            'loansGivenOutstanding' => $loansGivenOutstanding,
            'loansTakenOutstanding' => $loansTakenOutstanding,
            'topExpenses' => $topExpenses,
            'topIncomes' => $topIncomes,
        ]);
    }

    private function scalar(string $sql, array $params){
        $stmt=$this->db->prepare($sql); $stmt->execute($params); return $stmt->fetchColumn();
    }
    private function list(string $sql, array $params){
        $stmt=$this->db->prepare($sql); $stmt->execute($params); return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
}
