<?php require __DIR__ . '/../layout/header.php'; ?>
<h3 class="mb-3">Edit Wallet</h3>
<?php if (!empty($error)): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<form method="post">
  <?= csrf_field() ?>
  <div class="row g-3">
    <div class="col-md-6">
      <label class="form-label">Name</label>
      <input class="form-control" name="name" value="<?= e($wal['name']) ?>" required>
    </div>
    <div class="col-md-3">
      <label class="form-label">Type</label>
      <select class="form-select" name="type" required>
        <?php $types=['cash'=>'Cash','bank'=>'Bank','mobile'=>'Mobile','custom'=>'Custom']; foreach ($types as $k=>$v): ?>
          <option value="<?= $k ?>" <?= $wal['type']===$k?'selected':'' ?>><?= $v ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3">
      <label class="form-label">Balance</label>
      <input class="form-control" type="number" step="0.01" name="balance" value="<?= e((string)$wal['balance']) ?>">
    </div>
  </div>
  <div class="mt-3 d-flex gap-2">
    <button class="btn btn-primary" type="submit">Update</button>
    <a class="btn btn-secondary" href="index.php?route=wallets">Cancel</a>
  </div>
</form>
<?php require __DIR__ . '/../layout/footer.php'; ?>
