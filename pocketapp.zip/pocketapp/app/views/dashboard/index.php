<div class="container-fluid">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Welcome, <?= e($user['name']) ?></h3>
  </div>
  <div class="row g-3 mb-4">
    <div class="col-md-4">
      <div class="card"><div class="card-body bg-success-subtle"><div class="text-muted">Income (This Month)</div><div class="h3">₦<?= number_format($summary['income'], 2) ?></div></div></div>
    </div>
    <div class="col-md-4">
      <div class="card"><div class="card-body bg-danger-subtle"><div class="text-muted">Expenses (This Month)</div><div class="h3">₦<?= number_format($summary['expense'], 2) ?></div></div></div>
    </div>
    <div class="col-md-4">
      <div class="card"><div class="card-body"><div class="text-muted">Wallet Balance</div><div class="h3">₦<?= number_format($summary['wallets'], 2) ?></div></div></div>
    </div>
    <div class="col-md-4">
      <a class="text-decoration-none" href="index.php?route=goals">
        <div class="card"><div class="card-body bg-primary-subtle"><div class="text-muted">Wishlist Total</div><div class="h3">₦<?= number_format($wishlistTotal ?? 0, 2) ?></div></div></div>
      </a>
    </div>
    <div class="col-md-4">
      <div class="card"><div class="card-body"><div class="text-muted">Savings Target</div><div class="h3">₦<?= number_format($savingTarget ?? 0, 2) ?></div></div></div>
    </div>
    <div class="col-md-4">
      <div class="card"><div class="card-body"><div class="text-muted">Savings Achieved</div><div class="h3">₦<?= number_format($savingSaved ?? 0, 2) ?></div></div></div>
    </div>
    <div class="col-md-4">
      <a class="text-decoration-none" href="index.php?route=loans">
        <div class="card"><div class="card-body bg-warning-subtle">
          <div class="text-muted">Loans Given (Outstanding)</div>
          <div class="h3">₦<?= number_format($loansGivenOutstanding ?? 0, 2) ?></div>
        </div></div>
      </a>
    </div>
    <div class="col-md-4">
      <a class="text-decoration-none" href="index.php?route=loans">
        <div class="card"><div class="card-body bg-warning-subtle">
          <div class="text-muted">Total Debt to be Repaid</div>
          <div class="h3">₦<?= number_format($loansTakenOutstanding ?? 0, 2) ?></div>
        </div></div>
      </a>
    </div>
  </div>

  <div class="row g-3">
    <div class="col-md-6">
      <div class="card h-100"><div class="card-body">
        <h6 class="mb-3">Expense Categories (This Month)</h6>
        <ol class="list-group list-group-numbered">
          <?php if (!empty($topExpenses)): foreach ($topExpenses as $row): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              <span><?= e($row['name'] ?? 'Uncategorized') ?></span>
              <span class="badge bg-danger-subtle text-danger">₦<?= number_format((float)$row['total'], 2) ?></span>
            </li>
          <?php endforeach; else: ?>
            <li class="list-group-item">No data yet.</li>
          <?php endif; ?>
        </ol>
      </div></div>
    </div>
    <div class="col-md-6">
      <div class="card h-100"><div class="card-body">
        <h6 class="mb-3">Top 5 Income Categories (This Month)</h6>
        <ol class="list-group list-group-numbered">
          <?php if (!empty($topIncomes)): foreach ($topIncomes as $row): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              <span><?= e($row['name'] ?? 'Uncategorized') ?></span>
              <span class="badge bg-success-subtle text-success">₦<?= number_format((float)$row['total'], 2) ?></span>
            </li>
          <?php endforeach; else: ?>
            <li class="list-group-item">No data yet.</li>
          <?php endif; ?>
        </ol>
      </div></div>
    </div>
  </div>
</div>
