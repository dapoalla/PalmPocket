<?php
namespace App\Controllers;

use App\Core\Auth;
use PDO;

class BackupsController {
    private PDO $db; private Auth $auth;
    public function __construct(PDO $pdo, Auth $auth){ $this->db=$pdo; $this->auth=$auth; }

    public function index(): void {
        $uid = $this->auth->user()['id'];
        $rows = $this->mine('SELECT * FROM backups WHERE user_id=? ORDER BY created_at DESC', [$uid]);
        require __DIR__ . '/../views/backups/index.php';
    }

    public function create(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $time = date('Ymd_His');
        $data = [
            'users' => $this->mine('SELECT id,name,email,created_at FROM users WHERE id=?', [$uid]),
            'categories' => $this->mine('SELECT * FROM categories WHERE user_id=?', [$uid]),
            'wallets' => $this->mine('SELECT * FROM wallets WHERE user_id=?', [$uid]),
            'incomes' => $this->mine('SELECT * FROM incomes WHERE user_id=?', [$uid]),
            'expenses' => $this->mine('SELECT * FROM expenses WHERE user_id=?', [$uid]),
            'transfers' => $this->mine('SELECT * FROM transfers WHERE user_id=?', [$uid]),
            'budgets' => $this->mine('SELECT * FROM budgets WHERE user_id=?', [$uid]),
            'goals' => $this->mine('SELECT * FROM goals WHERE user_id=?', [$uid]),
            'settings' => $this->mine('SELECT * FROM settings WHERE user_id=?', [$uid]),
        ];
        $json = json_encode($data, JSON_PRETTY_PRINT);
        if (!is_dir(BACKUPS_DIR)) @mkdir(BACKUPS_DIR, 0755, true);
        $jsonPath = rtrim(BACKUPS_DIR, '/\\') . DIRECTORY_SEPARATOR . "backup_{$uid}_{$time}.json";
        file_put_contents($jsonPath, $json);

        // Optional: zip receipts
        $zipPath = null;
        if (class_exists('ZipArchive')) {
            $zipPath = rtrim(BACKUPS_DIR, '/\\') . DIRECTORY_SEPARATOR . "receipts_{$uid}_{$time}.zip";
            $zip = new \ZipArchive();
            if ($zip->open($zipPath, \ZipArchive::CREATE|\ZipArchive::OVERWRITE) === true) {
                $dir = RECEIPTS_DIR;
                if (is_dir($dir)) {
                    $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS));
                    foreach ($it as $file) {
                        $local = substr($file->getPathname(), strlen($dir) + 1);
                        $zip->addFile($file->getPathname(), $local);
                    }
                }
                $zip->close();
            } else {
                $zipPath = null;
            }
        }

        // Record backup
        $rel = 'backups/' . basename($jsonPath);
        $this->db->prepare('INSERT INTO backups(user_id,file_path) VALUES (?,?)')->execute([$uid, $rel]);

        redirect('backups');
    }

    public function download(): void {
        $uid = $this->auth->user()['id'];
        $id = (int)($_GET['id'] ?? 0);
        $row = $this->one('SELECT * FROM backups WHERE id=? AND user_id=?', [$id, $uid]);
        if (!$row) { http_response_code(404); exit('Not found'); }
        $full = dirname(__DIR__,2) . '/' . $row['file_path'];
        if (!is_file($full)) { http_response_code(404); exit('File not found'); }
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename=' . basename($full));
        readfile($full);
        exit;
    }

    public function import(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $error = '';$ok=false;
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_FILES['backup']['tmp_name'])) {
            $json = file_get_contents($_FILES['backup']['tmp_name']);
            $data = json_decode($json, true);
            if (!is_array($data)) { $error = 'Invalid JSON backup'; }
            else {
                $this->db->beginTransaction();
                try {
                    $tables = ['categories','wallets','incomes','expenses','transfers','budgets','goals','settings'];
                    foreach ($tables as $t) { $this->db->prepare("DELETE FROM {$t} WHERE user_id=?")->execute([$uid]); }
                    // Restore each table
                    foreach ($data['categories'] ?? [] as $r) {
                        $this->db->prepare('INSERT INTO categories(id,user_id,name,type,created_at) VALUES (?,?,?,?,?)')
                            ->execute([$r['id'],$uid,$r['name'],$r['type'],$r['created_at']]);
                    }
                    foreach ($data['wallets'] ?? [] as $r) {
                        $this->db->prepare('INSERT INTO wallets(id,user_id,name,type,balance,created_at) VALUES (?,?,?,?,?,?)')
                            ->execute([$r['id'],$uid,$r['name'],$r['type'],$r['balance'],$r['created_at']]);
                    }
                    foreach ($data['incomes'] ?? [] as $r) {
                        $this->db->prepare('INSERT INTO incomes(id,user_id,wallet_id,category_id,source,amount,date,note,created_at) VALUES (?,?,?,?,?,?,?,?,?)')
                            ->execute([$r['id'],$uid,$r['wallet_id'],$r['category_id'],$r['source'],$r['amount'],$r['date'],$r['note'],$r['created_at']]);
                    }
                    foreach ($data['expenses'] ?? [] as $r) {
                        $this->db->prepare('INSERT INTO expenses(id,user_id,wallet_id,category_id,description,amount,date,note,receipt_path,repeat_toggle,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
                            ->execute([$r['id'],$uid,$r['wallet_id'],$r['category_id'],$r['description'] ?? ($r['note'] ?? ''),$r['amount'],$r['date'],$r['note'],$r['receipt_path'],$r['repeat_toggle'],$r['created_at']]);
                    }
                    foreach ($data['transfers'] ?? [] as $r) {
                        $this->db->prepare('INSERT INTO transfers(id,user_id,from_wallet_id,to_wallet_id,amount,date,note,created_at) VALUES (?,?,?,?,?,?,?,?)')
                            ->execute([$r['id'],$uid,$r['from_wallet_id'],$r['to_wallet_id'],$r['amount'],$r['date'],$r['note'],$r['created_at']]);
                    }
                    foreach ($data['budgets'] ?? [] as $r) {
                        $this->db->prepare('INSERT INTO budgets(id,user_id,category_id,description,amount,start_date,end_date,created_at) VALUES (?,?,?,?,?,?,?,?)')
                            ->execute([$r['id'],$uid,$r['category_id'],$r['description'] ?? '',$r['amount'],$r['start_date'],$r['end_date'],$r['created_at']]);
                    }
                    foreach ($data['goals'] ?? [] as $r) {
                        $this->db->prepare('INSERT INTO goals(id,user_id,type,title,target_amount,saved_amount,deadline,wishlist_price,created_at) VALUES (?,?,?,?,?,?,?,?,?)')
                            ->execute([$r['id'],$uid,$r['type'] ?? 'saving',$r['title'],$r['target_amount'],$r['saved_amount'],$r['deadline'],$r['wishlist_price'],$r['created_at']]);
                    }
                    foreach ($data['settings'] ?? [] as $r) {
                        $this->db->prepare('INSERT INTO settings(id,user_id,k,v) VALUES (?,?,?,?)')
                            ->execute([$r['id'],$uid,$r['k'],$r['v']]);
                    }
                    $this->db->commit();
                    $ok = true;
                } catch (\Throwable $e) {
                    $this->db->rollBack();
                    $error = $e->getMessage();
                }
            }
            // Restore receipts from optional ZIP
            if ($ok && !empty($_FILES['receipts_zip']['tmp_name'])) {
                if (!class_exists('ZipArchive')) {
                    $error = 'ZipArchive not available on server; images not restored.';
                } else {
                    @mkdir(RECEIPTS_DIR, 0755, true);
                    $zip = new \ZipArchive();
                    if ($zip->open($_FILES['receipts_zip']['tmp_name']) === true) {
                        // Extract into RECEIPTS_DIR
                        $zip->extractTo(RECEIPTS_DIR);
                        $zip->close();
                    } else {
                        $error = 'Could not open receipts zip.';
                    }
                }
            }
        }
        $rows = $this->mine('SELECT * FROM backups WHERE user_id=? ORDER BY created_at DESC', [$uid]);
        require __DIR__ . '/../views/backups/index.php';
    }

    private function mine(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetchAll(PDO::FETCH_ASSOC); }
    private function one(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetch(PDO::FETCH_ASSOC); }
}
