<?php require __DIR__ . '/../layout/header.php'; ?>
<h3 class="mb-3">Add Income</h3>
<?php if (!empty($error)): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<form method="post">
  <?= csrf_field() ?>
  <div class="row g-3">
    <div class="col-12">
      <div class="form-check">
        <input class="form-check-input" type="checkbox" name="loan_taken" id="loan_taken">
        <label class="form-check-label" for="loan_taken">This income is a loan I took (to be repaid)</label>
      </div>
    </div>
    <div class="col-md-6">
      <label class="form-label">Lender Name</label>
      <input class="form-control" name="loan_party" placeholder="Who lent you?">
    </div>
    <div class="col-md-6">
      <label class="form-label">Due Date</label>
      <input class="form-control" type="date" name="loan_due">
    </div>
    <div class="col-md-3">
      <label class="form-label">Amount</label>
      <input class="form-control" type="number" step="0.01" name="amount" required>
    </div>
    <div class="col-md-3">
      <label class="form-label">Wallet</label>
      <select class="form-select" name="wallet_id" required>
        <?php foreach ($wallets as $w): ?><option value="<?= (int)$w['id'] ?>"><?= e($w['name']) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3">
      <label class="form-label">Category</label>
      <select class="form-select" name="category_id">
        <option value="">- none -</option>
        <?php foreach ($cats as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3">
      <label class="form-label">Date</label>
      <input class="form-control" type="date" name="date" value="<?= date('Y-m-d') ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Source</label>
      <input class="form-control" name="source">
    </div>
    <div class="col-md-6">
      <label class="form-label">Note</label>
      <input class="form-control" name="note">
    </div>
  </div>
  <div class="mt-3 d-flex gap-2">
    <button class="btn btn-primary" type="submit">Save</button>
    <a class="btn btn-secondary" href="index.php?route=incomes">Cancel</a>
  </div>
</form>
<?php require __DIR__ . '/../layout/footer.php'; ?>
