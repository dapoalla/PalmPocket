<?php
namespace App\Controllers;

use App\Core\Auth;
use PDO;

class GoalsController {
    private PDO $db; private Auth $auth;
    public function __construct(PDO $pdo, Auth $auth){ $this->db=$pdo; $this->auth=$auth; }

    public function index(): void {
        $uid = $this->auth->user()['id'];
        $rows = $this->mine('SELECT * FROM goals WHERE user_id=? ORDER BY created_at DESC', [$uid]);
        foreach ($rows as &$g) {
            $g['percent'] = $g['target_amount'] > 0 ? min(100, round(((float)$g['saved_amount'] / (float)$g['target_amount']) * 100)) : 0;
        }
        unset($g);
        $wishlistTotal = (float)$this->scalar("SELECT COALESCE(SUM(wishlist_price),0) FROM goals WHERE user_id=? AND type='wishlist'", [$uid]);
        $savingTotals = $this->one("SELECT COALESCE(SUM(target_amount),0) target, COALESCE(SUM(saved_amount),0) saved FROM goals WHERE user_id=? AND type='saving'", [$uid]);
        require __DIR__ . '/../views/goals/index.php';
    }

    public function create(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $type = $_POST['type'] ?? 'saving';
            $title = trim($_POST['title'] ?? '');
            $target = (float)($_POST['target_amount'] ?? 0);
            $deadline = $_POST['deadline'] ?: null;
            $wishlist = isset($_POST['wishlist_price']) && $_POST['wishlist_price'] !== '' ? (float)$_POST['wishlist_price'] : null;
            if (!in_array($type, ['saving','wishlist'], true)) $type = 'saving';
            if ($title === '' || ($type==='saving' && $target <= 0) || ($type==='wishlist' && ($wishlist===null || $wishlist<=0))) {
                $error = 'Title and target are required';
            } else {
                if ($type==='wishlist') { $target = $wishlist; }
                $this->db->prepare("INSERT INTO goals(user_id,type,title,target_amount,deadline,wishlist_price) VALUES (?,?,?,?,?,?)")
                    ->execute([$uid, $type, $title, $target, $deadline, $wishlist]);
                redirect('goals');
            }
        }
        require __DIR__ . '/../views/goals/create.php';
    }

    public function edit(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $id = (int)($_GET['id'] ?? 0);
        $goal = $this->one('SELECT * FROM goals WHERE id=? AND user_id=?', [$id, $uid]);
        if (!$goal) { http_response_code(404); exit('Not found'); }
        if ($goal['type'] !== 'saving') { http_response_code(400); exit('Only saving goals accept savings'); }
        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $type = $_POST['type'] ?? $goal['type'];
            $title = trim($_POST['title'] ?? '');
            $target = (float)($_POST['target_amount'] ?? 0);
            $deadline = $_POST['deadline'] ?: null;
            $wishlist = isset($_POST['wishlist_price']) && $_POST['wishlist_price'] !== '' ? (float)$_POST['wishlist_price'] : null;
            if (!in_array($type, ['saving','wishlist'], true)) $type = 'saving';
            if ($title === '' || ($type==='saving' && $target <= 0) || ($type==='wishlist' && ($wishlist===null || $wishlist<=0))) {
                $error = 'Title and target are required';
            } else {
                if ($type==='wishlist') { $target = $wishlist; }
                $this->db->prepare('UPDATE goals SET type=?, title=?, target_amount=?, deadline=?, wishlist_price=? WHERE id=? AND user_id=?')
                    ->execute([$type, $title, $target, $deadline, $wishlist, $id, $uid]);
                redirect('goals');
            }
        }
        require __DIR__ . '/../views/goals/edit.php';
    }

    public function delete(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $id = (int)($_GET['id'] ?? 0);
        $this->db->prepare('DELETE FROM goals WHERE id=? AND user_id=?')->execute([$id, $uid]);
        redirect('goals');
    }

    public function addSaving(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $id = (int)($_GET['id'] ?? ($_POST['id'] ?? 0));
        $goal = $this->one('SELECT * FROM goals WHERE id=? AND user_id=?', [$id, $uid]);
        if (!$goal) { http_response_code(404); exit('Not found'); }
        $wallets = $this->mine('SELECT id,name FROM wallets WHERE user_id=? ORDER BY name', [$uid]);
        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $amount = max(0, (float)($_POST['amount'] ?? 0));
            $wallet_id = (int)($_POST['wallet_id'] ?? 0);
            if ($amount <= 0 || $wallet_id <= 0) {
                $error = 'Invalid savings details';
            } else {
                $this->db->beginTransaction();
                try {
                    // Deduct from wallet
                    $this->db->prepare('UPDATE wallets SET balance=balance-? WHERE id=? AND user_id=?')->execute([$amount, $wallet_id, $uid]);
                    // Increase goal saved amount
                    $this->db->prepare('UPDATE goals SET saved_amount=saved_amount+? WHERE id=? AND user_id=?')->execute([$amount, $id, $uid]);
                    $this->db->commit();
                    redirect('goals');
                } catch (\Throwable $e) {
                    $this->db->rollBack();
                    $error = $e->getMessage();
                }
            }
        }
        require __DIR__ . '/../views/goals/add_saving.php';
    }

    private function mine(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetchAll(PDO::FETCH_ASSOC); }
    private function one(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetch(PDO::FETCH_ASSOC); }
    private function scalar(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetchColumn(); }
}
