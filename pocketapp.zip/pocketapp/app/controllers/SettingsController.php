<?php
namespace App\Controllers;

use App\Core\Auth;
use PDO;

class SettingsController {
    private PDO $db; private Auth $auth;
    public function __construct(PDO $pdo, Auth $auth){ $this->db=$pdo; $this->auth=$auth; }

    public function index(): void {
        $uid = $this->auth->user()['id'];
        $theme = $_SESSION['theme'] ?? ($_COOKIE['theme'] ?? 'dark');
        require __DIR__ . '/../views/settings/index.php';
    }

    public function saveTheme(): void {
        verify_csrf();
        $theme = $_POST['theme'] ?? 'dark';
        if (!in_array($theme, ['dark','light'], true)) $theme = 'dark';
        $_SESSION['theme'] = $theme;
        setcookie('theme', $theme, time()+86400*365, '/');
        redirect('settings');
    }

    public function changePassword(): void {
        verify_csrf();
        $uid = $this->auth->user()['id'];
        $error = '';$ok=false;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $current = (string)($_POST['current'] ?? '');
            $new = (string)($_POST['new'] ?? '');
            $confirm = (string)($_POST['confirm'] ?? '');
            if ($new === '' || $new !== $confirm) {
                $error = 'Passwords do not match';
            } else {
                $u = $this->one('SELECT password_hash FROM users WHERE id=?', [$uid]);
                if (!$u || !password_verify($current, $u['password_hash'])) {
                    $error = 'Current password is incorrect';
                } else {
                    $hash = password_hash($new, PASSWORD_DEFAULT);
                    $this->db->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([$hash, $uid]);
                    $ok = true;
                }
            }
        }
        $theme = $_SESSION['theme'] ?? ($_COOKIE['theme'] ?? 'dark');
        require __DIR__ . '/../views/settings/index.php';
    }

    private function one(string $sql, array $p){ $s=$this->db->prepare($sql); $s->execute($p); return $s->fetch(PDO::FETCH_ASSOC); }
}
